#!/usr/bin/env python3
"""
backup_agent.py — Backup/restore project to GitHub (generic, config-driven).

Commands:
  create              Create timestamped backup ZIP, upload to GitHub
  list                List backups on GitHub
  restore <timestamp> Restore from GitHub backup (needs PAT)
  local-create        Create local ZIP only (no GitHub)
  local-list          List local backups

Backup includes:
  - download/*.html, *.md, *.txt
  - scripts/ (all .py, .json, data/, images/)
  - restrictions/
  - project.json
  - upload/system_prompt_21plus_novel.txt

Backup stored on GitHub: backups/hp_backup_<timestamp>.zip
Backup stored locally: backups/hp_backup_<timestamp>.zip

Usage:
  python3 scripts/agents/backup_agent.py create
  python3 scripts/agents/backup_agent.py list
  python3 scripts/agents/backup_agent.py restore 20260802_230000
"""
import argparse
import base64
import hashlib
import json
import os
import sys
import zipfile
import requests
from datetime import datetime
from pathlib import Path

sys.path.insert(0, os.path.dirname(__file__))
from shared import *

BACKUP_DIR = f"{PROJECT_ROOT}/backups"
INCLUDE_PATHS = ["download", "scripts", "restrictions", "upload", "project.json"]
EXCLUDE = ["__pycache__", ".pyc", ".bak", "/tmp/", ".locks", ".lock"]
GH_BACKUP_FOLDER = "backups"


def should_exclude(path):
    return any(x in path for x in EXCLUDE)


def create_zip(zip_path):
    """Create ZIP backup. Returns (file_count, total_size)."""
    file_count = 0
    total_size = 0
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for inc_path in INCLUDE_PATHS:
            full_path = os.path.join(PROJECT_ROOT, inc_path)
            if not os.path.exists(full_path):
                continue
            if os.path.isfile(full_path):
                if should_exclude(full_path):
                    continue
                zf.write(full_path, inc_path)
                file_count += 1
                total_size += os.path.getsize(full_path)
                continue
            for root, dirs, files in os.walk(full_path):
                dirs[:] = [d for d in dirs if not should_exclude(os.path.join(root, d))]
                for file in files:
                    fp = os.path.join(root, file)
                    if should_exclude(fp):
                        continue
                    arcname = os.path.relpath(fp, PROJECT_ROOT)
                    zf.write(fp, arcname)
                    file_count += 1
                    total_size += os.path.getsize(fp)
    return file_count, total_size


def cmd_create(config, args):
    """Create backup: local ZIP + upload to GitHub."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    project_name = config.get("name", "project").replace(" ", "_").lower()
    zip_filename = f"{project_name}_backup_{timestamp}.zip"
    zip_path = os.path.join(BACKUP_DIR, zip_filename)

    # Create local ZIP
    print(f"Creating backup: {zip_filename}", flush=True)
    file_count, total_size = create_zip(zip_path)
    zip_size = os.path.getsize(zip_path)
    print(f"  ✓ Local ZIP: {file_count} files, {total_size:,} bytes → {zip_size:,} bytes compressed", flush=True)

    result = {
        "timestamp": timestamp,
        "filename": zip_filename,
        "local_path": zip_path,
        "files": file_count,
        "uncompressed_size": total_size,
        "compressed_size": zip_size,
    }

    # Upload to GitHub
    gh_config = load_github_config(config)
    token = load_github_token(config)
    if token:
        print(f"  → Uploading to GitHub...", flush=True)
        with open(zip_path, 'rb') as f:
            content = f.read()
        content_b64 = base64.b64encode(content).decode("ascii")

        gh_path = f"{GH_BACKUP_FOLDER}/{zip_filename}"
        url = f"https://api.github.com/repos/{gh_config['username']}/{gh_config['repo']}/contents/{gh_path}"
        headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}
        data = {"message": f"Backup {timestamp}", "content": content_b64, "branch": gh_config["branch"]}

        try:
            r = requests.put(url, headers=headers, json=data, timeout=120)
            if r.status_code in (200, 201):
                gh_url = f"https://raw.githubusercontent.com/{gh_config['username']}/{gh_config['repo']}/{gh_config['branch']}/{gh_path}"
                result["github_url"] = gh_url
                result["github_status"] = "ok"
                print(f"  ✓ GitHub: {gh_url}", flush=True)
            else:
                result["github_status"] = f"error: HTTP {r.status_code}"
                print(f"  ✗ GitHub upload failed: HTTP {r.status_code}", flush=True)
        except Exception as e:
            result["github_status"] = f"error: {e}"
            print(f"  ✗ GitHub upload error: {e}", flush=True)
    else:
        result["github_status"] = "skipped (no PAT)"
        print(f"  ℹ GitHub upload skipped (no PAT)", flush=True)

    output(result, args.verbose)


def cmd_list(config, args):
    """List backups (local + GitHub)."""
    result = {"local": [], "github": []}

    # Local backups
    if os.path.exists(BACKUP_DIR):
        for fname in sorted(os.listdir(BACKUP_DIR)):
            if fname.endswith(".zip"):
                size = os.path.getsize(os.path.join(BACKUP_DIR, fname))
                # Extract timestamp from filename
                ts_match = fname.split("backup_")[-1].replace(".zip", "") if "backup_" in fname else "?"
                result["local"].append({"filename": fname, "timestamp": ts_match, "size_bytes": size})

    # GitHub backups
    gh_config = load_github_config(config)
    token = load_github_token(config)
    if token:
        url = f"https://api.github.com/repos/{gh_config['username']}/{gh_config['repo']}/contents/{GH_BACKUP_FOLDER}?ref={gh_config['branch']}"
        headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}
        try:
            r = requests.get(url, headers=headers, timeout=30)
            if r.status_code == 200:
                for item in r.json():
                    if item.get("type") == "file" and item["name"].endswith(".zip"):
                        ts_match = item["name"].split("backup_")[-1].replace(".zip", "") if "backup_" in item["name"] else "?"
                        result["github"].append({
                            "filename": item["name"],
                            "timestamp": ts_match,
                            "size_bytes": item.get("size", 0),
                            "sha": item.get("sha", ""),
                        })
        except:
            pass

    output(result, args.verbose)


def cmd_restore(config, args):
    """Restore from backup (local or GitHub)."""
    timestamp = args.timestamp

    # Try local first
    project_name = config.get("name", "project").replace(" ", "_").lower()
    local_zip = None
    if os.path.exists(BACKUP_DIR):
        for fname in os.listdir(BACKUP_DIR):
            if timestamp in fname and fname.endswith(".zip"):
                local_zip = os.path.join(BACKUP_DIR, fname)
                break

    if local_zip:
        print(f"Restoring from local: {local_zip}", flush=True)
        zip_path = local_zip
    else:
        # Try GitHub
        gh_config = load_github_config(config)
        token = load_github_token(config)
        if not token:
            output({"status": "error", "message": "Backup not found locally and no PAT for GitHub"})
            return

        # Find on GitHub
        url = f"https://api.github.com/repos/{gh_config['username']}/{gh_config['repo']}/contents/{GH_BACKUP_FOLDER}?ref={gh_config['branch']}"
        headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}
        r = requests.get(url, headers=headers, timeout=30)
        if r.status_code != 200:
            output({"status": "error", "message": f"GitHub API error: {r.status_code}"})
            return

        gh_file = None
        for item in r.json():
            if item.get("type") == "file" and timestamp in item["name"] and item["name"].endswith(".zip"):
                gh_file = item
                break

        if not gh_file:
            output({"status": "error", "message": f"Backup with timestamp '{timestamp}' not found"})
            return

        # Download
        print(f"Downloading from GitHub: {gh_file['name']}", flush=True)
        raw_url = f"https://raw.githubusercontent.com/{gh_config['username']}/{gh_config['repo']}/{gh_config['branch']}/{GH_BACKUP_FOLDER}/{gh_file['name']}"
        r = requests.get(raw_url, timeout=120)
        if r.status_code != 200:
            output({"status": "error", "message": f"Download failed: {r.status_code}"})
            return

        zip_path = os.path.join(BACKUP_DIR, gh_file["name"])
        os.makedirs(BACKUP_DIR, exist_ok=True)
        with open(zip_path, 'wb') as f:
            f.write(r.content)
        print(f"  ✓ Downloaded: {len(r.content):,} bytes", flush=True)

    # Extract
    print(f"Extracting to {PROJECT_ROOT}...", flush=True)
    file_count = 0
    with zipfile.ZipFile(zip_path, 'r') as zf:
        for member in zf.namelist():
            target_path = os.path.join(PROJECT_ROOT, member)
            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            with zf.open(member) as src, open(target_path, "wb") as dst:
                dst.write(src.read())
            file_count += 1

    print(f"  ✓ Restored {file_count} files", flush=True)
    output({"status": "ok", "restored_files": file_count, "source": zip_path}, args.verbose)


def cmd_local_create(config, args):
    """Create local ZIP only."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    project_name = config.get("name", "project").replace(" ", "_").lower()
    zip_filename = f"{project_name}_backup_{timestamp}.zip"
    zip_path = os.path.join(BACKUP_DIR, zip_filename)

    file_count, total_size = create_zip(zip_path)
    zip_size = os.path.getsize(zip_path)

    output({
        "timestamp": timestamp,
        "filename": zip_filename,
        "local_path": zip_path,
        "files": file_count,
        "uncompressed_size": total_size,
        "compressed_size": zip_size,
    }, args.verbose)


def cmd_local_list(config, args):
    """List local backups only."""
    result = []
    if os.path.exists(BACKUP_DIR):
        for fname in sorted(os.listdir(BACKUP_DIR)):
            if fname.endswith(".zip"):
                size = os.path.getsize(os.path.join(BACKUP_DIR, fname))
                ts_match = fname.split("backup_")[-1].replace(".zip", "") if "backup_" in fname else "?"
                result.append({"filename": fname, "timestamp": ts_match, "size_bytes": size})
    output({"local_backups": result, "count": len(result)}, args.verbose)


def main():
    parser = argparse.ArgumentParser(description="Backup Agent")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("create", help="Create backup (local + GitHub)")
    sub.add_parser("list", help="List backups (local + GitHub)")
    p_restore = sub.add_parser("restore", help="Restore from backup")
    p_restore.add_argument("timestamp", help="Backup timestamp (e.g., 20260802_230000)")
    sub.add_parser("local-create", help="Create local ZIP only")
    sub.add_parser("local-list", help="List local backups only")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    config = load_config()
    if args.command == "create":
        cmd_create(config, args)
    elif args.command == "list":
        cmd_list(config, args)
    elif args.command == "restore":
        cmd_restore(config, args)
    elif args.command == "local-create":
        cmd_local_create(config, args)
    elif args.command == "local-list":
        cmd_local_list(config, args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
