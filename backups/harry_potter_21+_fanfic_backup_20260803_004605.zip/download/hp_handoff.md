# Harry Potter 21+ Fanfic — Project Handoff Document

> Tài liệu này giúp AI assistant mới hiểu nhanh project context.

## Project Overview

- **Tên project**: Harry Potter 21+ Fanfic
- **Nam chính**: Harry Potter (16 tuổi, ngầm hiểu 18+), năm đầu tiên Hogwarts
- **System prompt**: `/home/z/my-project/upload/system_prompt_21plus_novel.txt`
- **Config**: `/home/z/my-project/project.json` (generic, dùng cho mọi truyện)

## Architecture

```
/home/z/my-project/
├── project.json                  ← ⭐ Config (generic, dùng cho mọi truyện)
├── download/
│   ├── hp_bible.html             ← Character Bible (search box, Part A-F)
│   ├── hp_story_outline.html     ← Story outline (TOC, relationship diagram)
│   ├── hp_canon_reference.html   ← Canon Reference (150 events, 11 sections)
│   ├── hp_handoff.md             ← File này
│   └── pronoun_styles.md         ← 11 nhóm xưng hô (A-K) + Mix
├── scripts/
│   ├── canon_data.py             ← Canon data (150 events, 25 objects, etc.)
│   ├── build_html.py             ← Build Bible HTML
│   ├── build_outline_html.py     ← Build Outline HTML
│   ├── github_config.json
│   ├── .github_token
│   ├── data/
│   │   └── characters/           ← 35 individual JSON files (per-character)
│   └── agents/                   ← ⭐ 5 SEPARATE AGENTS (config-driven, generic)
│       ├── shared.py             ← Shared utilities (locking, output, config, lazy loading)
│       ├── image_agent.py        ← Image management (add, list, check, sync)
│       ├── story_agent.py        ← Story tracking (save-part, status, list)
│       ├── canon_agent.py        ← Canon reference (remind, search, list-events, build)
│       ├── build_agent.py        ← Rebuild HTML (all, bible, outline)
│       └── backup_agent.py       ← Backup/restore (create, list)
└── upload/
    └── system_prompt_21plus_novel.txt
```

### Agents (7 separate, config-driven, generic)

| Agent | File | Commands |
|---|---|---|
| **Image** | `image_agent.py` | `add <char_id> <url>`, `list <char_id>`, `check`, `sync` |
| **Story** | `story_agent.py` | `save-part <id> [--word-count N] [--characters] [--status] [--story-file]`, `status <id> <status>`, `list` |
| **Canon** | `canon_agent.py` | `remind <part_id>`, `search <query>`, `list-events [--book N]`, `build` |
| **Build** | `build_agent.py` | `all`, `bible`, `outline` |
| **Backup** | `backup_agent.py` | `create [--output]`, `list` |
| **Restriction** | `restriction_agent.py` | `check <text>`, `check-file <path>`, `add word/sentence/context/guidance`, `list`, `remove`, `stats` |
| **Prompt Sync** | `prompt_sync_agent.py` | `sync` (upload prompts to GitHub), `list` (list on GitHub) |

**All agents output compact JSON** (1-line). `--verbose` for pretty-print.

**Restriction Agent** (Agent 6 — ⭐ NEW):
- **3 scopes**: `global` (mọi truyện), `style:<name>` (theo genre), `project` (1 truyện)
- **4 types**: `banned_words` (exact + fuzzy match), `banned_sentences`, `context_limits` (frequency), `soft_guidance` (warnings)
- **Auto-check**: AI chạy `check-file` sau khi viết xong mỗi phần → sửa violations → re-check
- **Manual**: User có thể add/remove restrictions bất kỳ lúc nào

```bash
# Check text against restrictions
python3 scripts/agents/restriction_agent.py check "Ánh mắt long lanh..."
python3 scripts/agents/restriction_agent.py check-file /tmp/part1.txt

# Add restrictions
python3 scripts/agents/restriction_agent.py add word "nhấp nhô" --scope global --reason "Cấm" --similar "nhấp lên nhấp xuống"
python3 scripts/agents/restriction_agent.py add sentence "Em sắp ra rồi" --scope global --reason "Cấm câu"
python3 scripts/agents/restriction_agent.py add context "sex gym" --max 1 --per arc --scope project --reason "Hạn chế lặp location"
python3 scripts/agents/restriction_agent.py add guidance "Hạn chế miêu tả quần áo quá chi tiết" --scope global --priority medium

# List / remove / stats
python3 scripts/agents/restriction_agent.py list --scope global
python3 scripts/agents/restriction_agent.py remove bw001 --scope global
python3 scripts/agents/restriction_agent.py stats
```

**Pre-seeded restrictions** (from system prompt):
- 5 banned words (long lanh, sắc lẹm, tối sầm, đầu nhấp nhô, nghi lễ thanh tẩy)
- 18 banned sentences (19 cụm cấm từ system prompt 8.1)
- 4 context limits (thì thầm max 5/part, some max 2/arc, gym sex max 1/arc, thanh lý 60%)
- 5 soft guidance (global) + 4 (Hàn Quốc style) + 3 (Kiếm hiệp style) + 2 (HP project)

**Usage:**
```bash
# Image
python3 scripts/agents/image_agent.py add hermione_granger https://i.pinimg.com/...
python3 scripts/agents/image_agent.py list hermione_granger
python3 scripts/agents/image_agent.py check

# Story
python3 scripts/agents/story_agent.py save-part arc1_ch1_p1 --word-count 12500 --characters "Harry, Lily" --status done --story-file /tmp/p1.txt
python3 scripts/agents/story_agent.py list

# Canon
python3 scripts/agents/canon_agent.py remind arc1_ch1_p1
python3 scripts/agents/canon_agent.py search "Quidditch"
python3 scripts/agents/canon_agent.py list-events --book 1

# Build
python3 scripts/agents/build_agent.py all

# Backup
python3 scripts/agents/backup_agent.py create
python3 scripts/agents/backup_agent.py list
```

### Reusable cho truyện khác

Viết truyện khác (vd: Marvel fanfic):
1. Tạo `project.json` mới với paths mới
2. Tạo character JSONs trong `data/characters/`
3. Tạo canon data (nếu có)
4. **Same 5 agents work** — không cần sửa code

### Per-character JSON (lazy loading, token-efficient)

```
data/characters/
├── hermione_granger.json    ← 2 KB (chỉ load khi cần)
├── lily_potter.json         ← 2 KB
├── ...
└── 35 files total
```

Query "Hermione" → load chỉ `hermione_granger.json` (2 KB) thay vì toàn bộ 75 KB.

### File locking (chống conflict)

Mọi write operation có `fcntl.flock` — chống conflict khi 2+ sessions cùng ghi.

## Canon Reference

**File**: `download/hp_canon_reference.html` (126 KB)

**11 sections**: 7 Books · 150 Events · 25 Objects · 27 Locations · 21 Spells · 20 Creatures · 13 Character Arcs · 13 Relationship Evolutions · 15 Foreshadowing · 7 Themes · 20 Behind-the-Scenes

## Pronoun Styles

**File**: `download/pronoun_styles.md` (28 KB)

**11 styles** (A-K) + Mix. Mỗi style có 6 sections: bảng xưng hô, tự xưng, xưng hô khi làm tình, context variations, ví dụ HP, cấm.

## Rules mới (QUAN TRỌNG)

### Rule 1: AI KHÔNG tự viết sau khi đọc
AI chỉ confirm + đề nghị chọn pronoun style → chờ user yêu cầu.

### Rule 2: KHÔNG tự update Story Outline HTML
Chỉ update khi user xác nhận: "Lưu phần X vào file outline".

### Rule 3: Đề xuất Arc — text trong chat
Format text đơn giản (không HTML), cuối mỗi phần viết xong.

## Khởi động session mới

Copy paste prompt sau:

```
Hãy đọc các file sau để hiểu project context:

1. /home/z/my-project/upload/system_prompt_21plus_novel.txt → Rules 21+
2. /home/z/my-project/download/hp_handoff.md → Handoff + 3 rules
3. /home/z/my-project/download/pronoun_styles.md → 11 nhóm xưng hô (A-K)
4. /home/z/my-project/download/hp_bible.html → Character Bible
5. /home/z/my-project/download/hp_story_outline.html → Story outline
6. /home/z/my-project/download/hp_canon_reference.html → Canon reference (150 events)
7. /home/z/my-project/project.json → Project config

Sau khi đọc xong:
1. Confirm đã hiểu rules (đặc biệt 3 rules mới)
2. KHÔNG tự viết — chờ user yêu cầu
3. Đề nghị user chọn pronoun style (A-K)
4. Chờ user gửi gợi ý cốt truyện

Nam chính: Harry Potter (16 tuổi, ngầm 18+), năm đầu Hogwarts.

Agents: Dùng `python3 scripts/agents/<agent>.py` cho mọi operation.
```
