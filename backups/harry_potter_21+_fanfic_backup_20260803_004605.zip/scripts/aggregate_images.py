#!/usr/bin/env python3
"""
Validate image search results and extract URLs.
Output: /home/z/my-project/scripts/images/_aggregated.json
  {
    "<key>": {
      "urls": ["url1", "url2", ...],  # 1-3 URLs
      "primary": "url1",               # best one
      "source": "..."
    },
    ...
  }
"""
import json
import os
import re

IMG_DIR = "/home/z/my-project/scripts/images"
OUT = os.path.join(IMG_DIR, "_aggregated.json")

def parse_z_ai_output(text):
    """Handle both raw JSON and CLI output with status lines."""
    s = text.find("{")
    if s < 0:
        return None
    e = text.rfind("}")
    if e < s:
        return None
    try:
        return json.loads(text[s:e+1])
    except json.JSONDecodeError:
        return None

aggregated = {}
stats = {"ok": 0, "empty": 0, "error": 0, "missing": 0}

KEYS = [
    # Family characters (22)
    "iu","kim_taehee","kim_sungryung","kim_yoojung","tzuyu","jang_wonyoung",
    "han_hyojoo","song_hyekyo","jun_jihyun","lee_sungkyung","han_sohee",
    "lee_sunbin","kim_hyesoo","park_shinhye","kim_goeun","son_yejin",
    "jeun_somin","karina_aespa","kim_hyunjoo","yang_mi","mina_twice",
    "suzy",
    # Other characters (13)
    "song_jihyo","chae_soobin","park_boyoung","zhao_lusi","dilireba",
    "kim_jiwon","irene_redvelvet","lee_youngae","liu_yifei","han_jimin",
    "park_siyeon","oh_nara","seulgi_redvelvet",
]

for key in KEYS:
    path = os.path.join(IMG_DIR, f"{key}.json")
    if not os.path.exists(path):
        aggregated[key] = {"urls": [], "primary": None, "source": "missing"}
        stats["missing"] += 1
        continue
    with open(path) as f:
        raw = f.read()
    data = parse_z_ai_output(raw)
    if not data or not data.get("success") or not data.get("results"):
        aggregated[key] = {"urls": [], "primary": None, "source": "parse_error"}
        stats["error"] += 1
        continue
    urls = [r.get("original_url") for r in data["results"] if r.get("original_url")]
    urls = [u for u in urls if u and (u.startswith("http") or u.startswith("images/"))]
    if not urls:
        aggregated[key] = {"urls": [], "primary": None, "source": "no_urls"}
        stats["empty"] += 1
        continue
    aggregated[key] = {
        "urls": urls[:3],
        "primary": urls[0],
        "source": data["results"][0].get("source", "unknown"),
    }
    stats["ok"] += 1

with open(OUT, "w") as f:
    json.dump(aggregated, f, ensure_ascii=False, indent=2)

print(f"Aggregated {len(aggregated)} entries -> {OUT}")
print(f"Stats: {stats}")
print("\nFailed entries (need fallback):")
for k, v in aggregated.items():
    if not v["primary"]:
        print(f"  - {k}: {v['source']}")
