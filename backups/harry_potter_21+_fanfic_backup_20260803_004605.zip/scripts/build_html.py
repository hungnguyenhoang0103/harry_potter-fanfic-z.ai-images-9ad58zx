#!/usr/bin/env python3
"""
Generate HTML Bible page for Harry Potter 21+ Fanfic.
Output: /home/z/my-project/download/hp_bible.html
"""
import json
import os
import html
from pathlib import Path

# Import character data
import sys
sys.path.insert(0, "/home/z/my-project/scripts")
from character_data import HARRY_OVERVIEW, FAMILY_CHARACTERS, OTHER_CHARACTERS, ARC_PROPOSAL

# Load aggregated image URLs
with open("/home/z/my-project/scripts/images/_aggregated.json") as f:
    IMAGES = json.load(f)

OUT_PATH = "/home/z/my-project/download/hp_bible.html"


def esc(s):
    return html.escape(str(s)) if s else ""


def get_image_urls(key, max_count=3):
    """Get up to max_count image URLs for a character."""
    entry = IMAGES.get(key, {})
    return entry.get("urls", [])[:max_count]


def render_image_widget(char):
    """Render image grid widget (1-3 images) for a character."""
    urls = get_image_urls(char["image_key"], max_count=3)
    if not urls:
        return '<div class="img-widget empty">Không có ảnh tham chiếu</div>'

    n = len(urls)
    grid_class = f"img-grid count-{n}"

    items = []
    for i, url in enumerate(urls):
        items.append(f"""
        <div class="img-cell" data-img-url="{esc(url)}">
          <img src="{esc(url)}" alt="{esc(char['name'])} - ảnh {i+1}" loading="lazy"
               onerror="this.parentElement.classList.add('img-error'); this.style.display='none';"/>
        </div>
        """)

    return f"""
    <div class="img-widget">
      <div class="img-widget-header">
        <span class="widget-icon">📷</span>
        <span class="widget-label">Widget ảnh tham chiếu thật — {esc(char['reference'])}</span>
      </div>
      <div class="{grid_class}">
        {''.join(items)}
      </div>
      <div class="img-widget-footer">
        <span class="footer-hint">Click ảnh để xem cỡ lớn · Nguồn: ZAI image-search</span>
      </div>
    </div>
    """


def render_character_card(char, idx, group_label):
    """Render one character card with full description + image widget."""
    appearance = char.get("appearance", {})
    return f"""
    <article class="char-card" id="{esc(char['id'])}">
      <header class="char-header">
        <div class="char-num">{idx:02d}</div>
        <div class="char-title">
          <h3 class="char-name">{esc(char['name'])}</h3>
          <div class="char-meta">
            <span class="meta-pill age">{esc(char['age'])} tuổi</span>
            <span class="meta-pill house">{esc(char.get('house', '—'))}</span>
            <span class="meta-pill blood">{esc(char.get('blood_status', '—'))}</span>
            <span class="meta-pill group">{esc(group_label)}</span>
          </div>
          <p class="char-role">{esc(char['role'])}</p>
          <p class="char-age-note"><em>Age note:</em> {esc(char['age_note'])}</p>
        </div>
        <div class="char-ref-badge">
          <div class="ref-label">Tham chiếu showbiz</div>
          <div class="ref-name">{esc(char['reference'])}</div>
        </div>
      </header>

      {render_image_widget(char)}

      <div class="char-body">
        <section class="char-section appearance">
          <h4 class="section-title">👤 Miêu tả ngoại hình (đầu → chân)</h4>
          <div class="appearance-grid">
            <div class="appr-row">
              <span class="appr-label">Gương mặt</span>
              <span class="appr-text">{esc(appearance.get('face', '—'))}</span>
            </div>
            <div class="appr-row">
              <span class="appr-label">Kiểu tóc</span>
              <span class="appr-text">{esc(appearance.get('hair', '—'))}</span>
            </div>
            <div class="appr-row">
              <span class="appr-label">Trang điểm</span>
              <span class="appr-text">{esc(appearance.get('makeup', '—'))}</span>
            </div>
            <div class="appr-row">
              <span class="appr-label">Trang phục</span>
              <span class="appr-text">{esc(appearance.get('outfit', '—'))}</span>
            </div>
            <div class="appr-row">
              <span class="appr-label">Trang sức</span>
              <span class="appr-text">{esc(appearance.get('jewelry', '—'))}</span>
            </div>
            <div class="appr-row">
              <span class="appr-label">Giày dép</span>
              <span class="appr-text">{esc(appearance.get('shoes', '—'))}</span>
            </div>
          </div>
        </section>

        <section class="char-section">
          <h4 class="section-title">🎭 Tính cách</h4>
          <p class="char-text">{esc(char['personality'])}</p>
        </section>

        <section class="char-section">
          <h4 class="section-title">🔗 Quan hệ với Harry</h4>
          <p class="char-text">{esc(char['relation_to_harry'])}</p>
        </section>

        <section class="char-section">
          <h4 class="section-title">📚 Vai trò trong arc</h4>
          <p class="char-text arc-role-text">{esc(char['arc_role'])}</p>
        </section>
      </div>
    </article>
    """


def render_harry_overview():
    """Render Part A: Harry Potter overview."""
    achievements_html = ""
    for a in HARRY_OVERVIEW["achievements"]:
        achievements_html += f"<li>{esc(a)}</li>"

    male_rels_html = ""
    for r in HARRY_OVERVIEW["male_relationships"]:
        male_rels_html += f"""
        <div class="rel-card">
          <div class="rel-name">{esc(r['name'])}</div>
          <div class="rel-desc">{esc(r['rel'])}</div>
        </div>
        """

    return f"""
    <section class="harry-overview" id="harry-overview">
      <div class="overview-header">
        <div class="hero-emblem">⚡</div>
        <h2 class="hero-title">{esc(HARRY_OVERVIEW['name'])}</h2>
        <div class="hero-subtitle">
          <span class="age-badge">{esc(HARRY_OVERVIEW['age_written'])} tuổi</span>
          <span class="age-disclaimer">· (ngầm hiểu {esc(HARRY_OVERVIEW['age_actual'])}+)</span>
          <span class="separator">·</span>
          <span class="house-badge">{esc(HARRY_OVERVIEW['house'])}</span>
        </div>
        <p class="hero-birthday">{esc(HARRY_OVERVIEW['birthday'])}</p>
      </div>

      <div class="overview-grid">
        <div class="overview-stats">
          <div class="stat-row"><span class="stat-key">Huyết thống</span><span class="stat-val">{esc(HARRY_OVERVIEW['blood_status'])}</span></div>
          <div class="stat-row"><span class="stat-key">Đũa phép</span><span class="stat-val">{esc(HARRY_OVERVIEW['wand'])}</span></div>
          <div class="stat-row"><span class="stat-key">Thần hộ mệnh</span><span class="stat-val">{esc(HARRY_OVERVIEW['patronus'])}</span></div>
          <div class="stat-row"><span class="stat-key">Nghề nghiệp</span><span class="stat-val">{esc(HARRY_OVERVIEW['occupation'])}</span></div>
        </div>

        <div class="overview-block background">
          <h3>Bối cảnh &amp; Hoàn cảnh</h3>
          <p>{esc(HARRY_OVERVIEW['background'])}</p>
        </div>

        <div class="overview-block personality">
          <h3>Tính cách</h3>
          <p>{esc(HARRY_OVERVIEW['personality'])}</p>
        </div>

        <div class="overview-block achievements">
          <h3>Thành tựu nổi bật</h3>
          <ul class="ach-list">{achievements_html}</ul>
        </div>

        <div class="overview-block summary">
          <h3>Tóm tắt vai trò chính</h3>
          <p>{esc(HARRY_OVERVIEW['summary'])}</p>
        </div>

        <div class="overview-block male-rels">
          <h3>Mối quan hệ nam (bạn bè, đối thủ, mentor)</h3>
          <div class="rel-grid">{male_rels_html}</div>
        </div>
      </div>
    </section>
    """


def render_arc_proposal():
    """Render Part D: Arc proposal for next chapter."""
    family_items = "".join(
        f'<li class="arc-item"><span class="arc-name">{esc(n)}</span><span class="arc-desc">{esc(d)}</span></li>'
        for n, d in ARC_PROPOSAL["family_top10"]
    )
    other_items = "".join(
        f'<li class="arc-item"><span class="arc-name">{esc(n)}</span><span class="arc-desc">{esc(d)}</span></li>'
        for n, d in ARC_PROPOSAL["other_top10"]
    )
    bonus_items = "".join(
        f'<li class="arc-item bonus"><span class="arc-name">{esc(n)}</span><span class="arc-desc">{esc(d)}</span></li>'
        for n, d in ARC_PROPOSAL["bonus"]
    )

    return f"""
    <section class="arc-proposal" id="arc-proposal">
      <header class="section-header">
        <h2 class="section-h2">Đề xuất Arc Tiếp Theo</h2>
        <p class="section-sub">Sau khi hoàn thành Bible, đề xuất 10 nhân vật nữ gia tộc + 10 nhân vật nữ khác (+ 14 bonus) cho Arc đầu tiên</p>
      </header>

      <div class="arc-grid">
        <div class="arc-column">
          <h3 class="arc-column-title">A · 10 Nhân Vật Nữ Gia Tộc</h3>
          <ol class="arc-list">{family_items}</ol>
        </div>

        <div class="arc-column">
          <h3 class="arc-column-title">B · 10 Nhân Vật Nữ Khác</h3>
          <ol class="arc-list">{other_items}</ol>
        </div>
      </div>

      <div class="arc-bonus">
        <h3 class="arc-column-title">C · 14 Nhân Vật Bonus (để chọn xen kẽ hoặc arc sau)</h3>
        <ol class="arc-list bonus">{bonus_items}</ol>
      </div>
    </section>
    """


def build_html():
    family_cards = "".join(
        render_character_card(c, i + 1, "GIA TỘC")
        for i, c in enumerate(FAMILY_CHARACTERS)
    )
    other_cards = "".join(
        render_character_card(c, i + 1, "KHÁC")
        for i, c in enumerate(OTHER_CHARACTERS)
    )

    family_nav = "".join(
        f'<a href="#{esc(c["id"])}" class="nav-chip">{esc(c["name"].split(" (")[0])}</a>'
        for c in FAMILY_CHARACTERS
    )
    other_nav = "".join(
        f'<a href="#{esc(c["id"])}" class="nav-chip">{esc(c["name"].split(" (")[0])}</a>'
        for c in OTHER_CHARACTERS
    )

    return f"""<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Harry Potter 21+ Fanfic · Bible Nhân Vật</title>
<style>{CSS}</style>
</head>
<body>
<nav class="top-nav">
  <div class="nav-inner">
    <a href="#cover" class="nav-brand">⚡ HP·21+ Bible</a>
    <div class="nav-links">
      <a href="#harry-overview">Harry</a>
      <a href="#family">Gia tộc (22)</a>
      <a href="#others">Khác (13)</a>
      <a href="#arc-proposal">Đề xuất Arc</a>
      <a href="#story-outline-link">Outline</a>
      <a href="#canon-reference-link">Canon</a>
      <a href="#canon-reference-link">Canon</a>
    </div>
    <div class="nav-stats">
      <span>35 nhân vật nữ</span>
      <span>·</span>
      <span>35 ảnh thật</span>
    </div>
  </div>
</nav>

<header class="cover" id="cover">
  <div class="cover-bg"></div>
  <div class="cover-content">
    <div class="cover-emblem">⚡</div>
    <h1 class="cover-title">Harry Potter</h1>
    <div class="cover-subtitle">21+ Fanfic · Bible Nhân Vật</div>
    <div class="cover-meta">
      <div class="cover-meta-item">
        <span class="meta-key">Nam chính</span>
        <span class="meta-val">Harry James Potter · 16 tuổi <em>(ngầm 18+)</em></span>
      </div>
      <div class="cover-meta-item">
        <span class="meta-key">Bối cảnh</span>
        <span class="meta-val">Nhận thư mời Hogwarts · năm đầu tiên</span>
      </div>
      <div class="cover-meta-item">
        <span class="meta-key">Phạm vi</span>
        <span class="meta-val">22 nhân vật nữ gia tộc + 13 nhân vật nữ khác</span>
      </div>
      <div class="cover-meta-item">
        <span class="meta-key">Tham chiếu</span>
        <span class="meta-val">Diễn viên HQ · Idol Kpop · Diễn viên Trung (tới 2026)</span>
      </div>
    </div>
    <div class="cover-disclaimer">
      ⚠ Tài liệu tham khảo nội bộ · Fanfiction 21+ · Sử dụng nguyên tác Harry Potter của J.K. Rowling làm nền.
      Hình ảnh tham chiếu lấy từ nguồn công khai (tạp chí, sự kiện, photoshoot) — chỉ dùng để hình dung nhân vật hư cấu.
    </div>
  </div>
</header>

<main class="main">

<section class="section" id="section-harry">
  <header class="section-header">
    <h2 class="section-h2">Part A · Nam Chính Harry Potter 16 Tuổi</h2>
    <p class="section-sub">Bối cảnh, hoàn cảnh, thành tựu, các mối quan hệ nam (bạn bè, đối thủ, mentor, gia đình)</p>
  </header>
  {render_harry_overview()}
</section>

<section class="section" id="family">
  <header class="section-header">
    <h2 class="section-h2">Part B · 22 Nhân Vật Nữ Gia Tộc</h2>
    <p class="section-sub">Potter · Weasley · Black · Longbottom · Malfoy · Diggory · Dursley · Greengrass · Dumbledore · Zabini · Delacour</p>
  </header>
  <div class="nav-chips">{family_nav}</div>
  <div class="cards-grid">
    {family_cards}
  </div>
</section>

<section class="section" id="others">
  <header class="section-header">
    <h2 class="section-h2">Part C · 13 Nhân Vật Nữ Khác</h2>
    <p class="section-sub">Học sinh cùng trường · Tiền bối · Giáo viên · Nhân vật ngoài trường</p>
  </header>
  <div class="nav-chips">{other_nav}</div>
  <div class="cards-grid">
    {other_cards}
  </div>
</section>

{render_arc_proposal()}

<section class="section" id="story-outline-link">
  <header class="section-header">
    <h2 class="section-h2">Part E · Story Outline</h2>
    <p class="section-sub">Cấu trúc ARC > Chương > Phần · Status tracking · Copy-paste prompts cho writing sessions</p>
  </header>
  <div class="outline-link-card">
    <div class="outline-link-icon">📖</div>
    <div class="outline-link-body">
      <h3 class="outline-link-title">hp_story_outline.html</h3>
      <p class="outline-link-desc">File outline độc lập với TOC navigation, status badges (draft/writing/done), character tracking table, và copy-paste prompts cho từng phần. Update tự động bởi <code>story-outline-manager</code> skill sau mỗi lần viết xong phần.</p>
      <div class="outline-link-actions">
        <a href="hp_story_outline.html" class="outline-btn primary" target="_blank">
          🔗 Mở file outline
        </a>
        <a href="hp_story_outline.html" class="outline-btn secondary" download>
          ⬇ Download outline
        </a>
      </div>
    </div>
  </div>
</section>


<section class="section" id="canon-reference-link">
  <header class="section-header">
    <h2 class="section-h2">Part F · Nguyên Tác Reference</h2>
    <p class="section-sub">7 books · 150 events · 25 objects · 27 locations · 21 spells · 20 creatures · Reference for staying true to canon</p>
  </header>
  <div class="outline-link-card">
    <div class="outline-link-icon">📚</div>
    <div class="outline-link-body">
      <h3 class="outline-link-title">hp_canon_reference.html</h3>
      <p class="outline-link-desc">Detailed canon reference: 7 books, 150 events, key objects, locations, spells, magical creatures, character arcs, relationship evolution, foreshadowing, themes, behind-the-scenes. Used by AI to bám sát nguyên tác.</p>
      <div class="outline-link-actions"><a href="hp_canon_reference.html" class="outline-btn primary" target="_blank">🔗 Mở Canon Reference</a></div>
    </div>
  </div>
</section>

<section class="section" id="canon-reference-link">
  <header class="section-header">
    <h2 class="section-h2">Part F · Nguyên Tác Reference</h2>
    <p class="section-sub">7 books · 150 events · 25 objects · 27 locations · 21 spells · 20 creatures · Reference for staying true to canon</p>
  </header>
  <div class="outline-link-card">
    <div class="outline-link-icon">📚</div>
    <div class="outline-link-body">
      <h3 class="outline-link-title">hp_canon_reference.html</h3>
      <p class="outline-link-desc">Detailed canon reference: 7 books, 150 events, key objects, locations, spells, magical creatures, character arcs, relationship evolution, foreshadowing, themes, behind-the-scenes. Used by AI to bám sát nguyên tác.</p>
      <div class="outline-link-actions"><a href="hp_canon_reference.html" class="outline-btn primary" target="_blank">🔗 Mở Canon Reference</a></div>
    </div>
  </div>
</section>
</main>

<footer class="footer">
  <div class="footer-inner">
    <div>Harry Potter 21+ Fanfic · Bible v1.0</div>
    <div>35 nhân vật nữ · 35 ảnh tham chiếu · 10+10+14 đề xuất arc</div>
    <div>Sẵn sàng cho Chương 1 · Phần 1 (~10.000+ từ)</div>
  </div>
</footer>

<!-- Lightbox -->
<div id="lightbox" class="lightbox" hidden>
  <span class="lightbox-close" onclick="closeLightbox()">×</span>
  <img id="lightbox-img" src="" alt="preview"/>
</div>

<script>{JS}</script>
</body>
</html>"""


CSS = """
* { margin: 0; padding: 0; box-sizing: border-box; }
html { scroll-behavior: smooth; scroll-padding-top: 80px; }
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Noto Sans', 'Helvetica Neue', sans-serif;
  background: #0a0612;
  color: #e8e3d3;
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
}

/* === TOP NAV === */
.top-nav {
  position: sticky; top: 0; z-index: 100;
  background: rgba(10, 6, 18, 0.92);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(180, 140, 80, 0.25);
  padding: 12px 0;
}
.nav-inner {
  max-width: 1400px; margin: 0 auto; padding: 0 24px;
  display: flex; align-items: center; gap: 24px;
}
.nav-brand {
  font-weight: 800; color: #d4a857; text-decoration: none;
  font-size: 16px; letter-spacing: 0.5px;
}
.nav-links { display: flex; gap: 18px; flex: 1; }
.nav-links a {
  color: #b8ad95; text-decoration: none; font-size: 14px;
  padding: 4px 0; border-bottom: 2px solid transparent;
  transition: color 0.2s, border-color 0.2s;
}
.nav-links a:hover { color: #e8d5a0; border-bottom-color: #d4a857; }
.nav-stats {
  font-size: 12px; color: #8a7e6a; display: flex; gap: 6px;
}
@media (max-width: 768px) { .nav-stats { display: none; } .nav-links { gap: 12px; font-size: 13px; } }

/* === COVER === */
.cover {
  position: relative; min-height: 85vh;
  display: flex; align-items: center; justify-content: center;
  overflow: hidden; padding: 60px 24px;
}
.cover-bg {
  position: absolute; inset: 0;
  background:
    radial-gradient(ellipse at top, rgba(80, 50, 120, 0.35) 0%, transparent 60%),
    radial-gradient(ellipse at bottom right, rgba(180, 130, 60, 0.18) 0%, transparent 50%),
    linear-gradient(180deg, #0a0612 0%, #150a25 100%);
}
.cover-bg::before {
  content: ''; position: absolute; inset: 0;
  background-image:
    radial-gradient(circle at 20% 30%, rgba(212, 168, 87, 0.4) 0%, transparent 1px),
    radial-gradient(circle at 70% 60%, rgba(212, 168, 87, 0.3) 0%, transparent 1px),
    radial-gradient(circle at 40% 80%, rgba(212, 168, 87, 0.35) 0%, transparent 1px);
  background-size: 200px 200px, 150px 150px, 180px 180px;
  opacity: 0.6;
}
.cover-content {
  position: relative; z-index: 1; text-align: center; max-width: 900px;
}
.cover-emblem {
  font-size: 80px; margin-bottom: 20px;
  filter: drop-shadow(0 0 30px rgba(212, 168, 87, 0.6));
  animation: pulse 3s ease-in-out infinite;
}
@keyframes pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.05); }
}
.cover-title {
  font-size: clamp(48px, 8vw, 96px);
  font-weight: 900; letter-spacing: -2px;
  background: linear-gradient(135deg, #f4d77a 0%, #d4a857 50%, #b88a3a 100%);
  -webkit-background-clip: text; background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 12px;
}
.cover-subtitle {
  font-size: 22px; color: #b8ad95;
  letter-spacing: 4px; text-transform: uppercase;
  margin-bottom: 40px;
}
.cover-meta {
  display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 16px; max-width: 800px; margin: 0 auto 32px;
}
.cover-meta-item {
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(212, 168, 87, 0.2);
  border-radius: 12px; padding: 16px 20px; text-align: left;
}
.meta-key {
  display: block; font-size: 11px; color: #8a7e6a;
  letter-spacing: 1.5px; text-transform: uppercase; margin-bottom: 6px;
}
.meta-val { font-size: 14px; color: #e8d5a0; }
.meta-val em { color: #d4a857; font-style: normal; font-weight: 600; }
.cover-disclaimer {
  font-size: 12px; color: #6a604f; max-width: 700px; margin: 0 auto;
  padding: 12px 20px; border-top: 1px solid rgba(212, 168, 87, 0.15);
  line-height: 1.7;
}

/* === MAIN === */
.main { max-width: 1400px; margin: 0 auto; padding: 80px 24px; }
.section { margin-bottom: 120px; }
.section-header { margin-bottom: 48px; text-align: center; }
.section-h2 {
  font-size: clamp(28px, 4vw, 42px); font-weight: 800;
  background: linear-gradient(135deg, #f4d77a 0%, #d4a857 100%);
  -webkit-background-clip: text; background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 12px; letter-spacing: -0.5px;
}
.section-sub {
  font-size: 15px; color: #8a7e6a; max-width: 700px; margin: 0 auto;
}

/* === NAV CHIPS === */
.nav-chips {
  display: flex; flex-wrap: wrap; gap: 8px; justify-content: center;
  margin-bottom: 48px; padding: 16px;
  background: rgba(255, 255, 255, 0.02);
  border-radius: 12px; border: 1px solid rgba(180, 140, 80, 0.15);
}
.nav-chip {
  font-size: 12px; padding: 6px 12px;
  background: rgba(212, 168, 87, 0.08);
  border: 1px solid rgba(212, 168, 87, 0.2);
  color: #b8ad95; text-decoration: none; border-radius: 999px;
  transition: all 0.2s;
}
.nav-chip:hover {
  background: rgba(212, 168, 87, 0.2);
  color: #f4d77a; border-color: #d4a857;
}

/* === HARRY OVERVIEW === */
.harry-overview {
  background: linear-gradient(180deg, rgba(20, 12, 35, 0.6) 0%, rgba(10, 6, 18, 0.4) 100%);
  border: 1px solid rgba(212, 168, 87, 0.25);
  border-radius: 20px; padding: 48px; overflow: hidden;
}
.overview-header { text-align: center; margin-bottom: 48px; }
.hero-emblem {
  font-size: 64px; margin-bottom: 16px;
  filter: drop-shadow(0 0 20px rgba(212, 168, 87, 0.5));
}
.hero-title {
  font-size: 48px; font-weight: 900; letter-spacing: -1px;
  background: linear-gradient(135deg, #f4d77a 0%, #d4a857 100%);
  -webkit-background-clip: text; background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 12px;
}
.hero-subtitle {
  font-size: 18px; color: #b8ad95; margin-bottom: 8px;
}
.age-badge {
  background: rgba(212, 168, 87, 0.15);
  border: 1px solid #d4a857; color: #f4d77a;
  padding: 4px 12px; border-radius: 999px; font-weight: 600;
}
.age-disclaimer { color: #8a7e6a; font-style: italic; font-size: 14px; }
.separator { color: #4a4030; margin: 0 8px; }
.house-badge { color: #b8ad95; }
.hero-birthday { font-size: 13px; color: #6a604f; }

.overview-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 32px;
}
@media (max-width: 900px) { .overview-grid { grid-template-columns: 1fr; } }

.overview-stats {
  grid-column: 1 / -1;
  display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px;
  background: rgba(0, 0, 0, 0.25); padding: 20px; border-radius: 12px;
}
.stat-row {
  display: flex; flex-direction: column; gap: 4px;
}
.stat-key {
  font-size: 10px; color: #8a7e6a; letter-spacing: 1.2px; text-transform: uppercase;
}
.stat-val { font-size: 14px; color: #e8d5a0; }

.overview-block {
  background: rgba(255, 255, 255, 0.025);
  border: 1px solid rgba(212, 168, 87, 0.15);
  border-radius: 14px; padding: 24px;
}
.overview-block h3 {
  font-size: 16px; color: #d4a857; margin-bottom: 14px;
  letter-spacing: 0.5px; font-weight: 700;
  border-bottom: 1px solid rgba(212, 168, 87, 0.2); padding-bottom: 10px;
}
.overview-block p {
  font-size: 14px; color: #c8bda5; line-height: 1.8;
}
.ach-list {
  list-style: none; padding: 0;
}
.ach-list li {
  position: relative; padding-left: 24px; margin-bottom: 10px;
  font-size: 13.5px; color: #c8bda5; line-height: 1.7;
}
.ach-list li::before {
  content: '⚡'; position: absolute; left: 0; top: 0;
  color: #d4a857; font-size: 14px;
}

.rel-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 12px;
}
.rel-card {
  background: rgba(0, 0, 0, 0.2);
  border-left: 3px solid #d4a857;
  padding: 12px 14px; border-radius: 8px;
}
.rel-name {
  font-size: 13px; font-weight: 700; color: #f4d77a; margin-bottom: 4px;
}
.rel-desc {
  font-size: 12.5px; color: #a89d85; line-height: 1.6;
}

/* === CHARACTER CARDS === */
.cards-grid {
  display: grid; grid-template-columns: 1fr; gap: 32px;
}
.char-card {
  background: linear-gradient(180deg, rgba(20, 12, 35, 0.7) 0%, rgba(10, 6, 18, 0.5) 100%);
  border: 1px solid rgba(212, 168, 87, 0.2);
  border-radius: 18px; overflow: hidden;
  transition: border-color 0.3s, transform 0.3s;
}
.char-card:hover {
  border-color: rgba(212, 168, 87, 0.5);
}

.char-header {
  display: grid; grid-template-columns: 80px 1fr auto; gap: 20px;
  padding: 24px 28px; align-items: start;
  background: linear-gradient(90deg, rgba(212, 168, 87, 0.06) 0%, transparent 100%);
  border-bottom: 1px solid rgba(212, 168, 87, 0.15);
}
@media (max-width: 700px) {
  .char-header { grid-template-columns: 1fr; }
}
.char-num {
  font-size: 36px; font-weight: 900; color: #d4a857;
  letter-spacing: -1px; line-height: 1;
  background: linear-gradient(135deg, #f4d77a 0%, #b88a3a 100%);
  -webkit-background-clip: text; background-clip: text;
  -webkit-text-fill-color: transparent;
}
.char-name {
  font-size: 22px; font-weight: 800; color: #f4d77a;
  margin-bottom: 8px; letter-spacing: -0.3px;
}
.char-meta {
  display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px;
}
.meta-pill {
  font-size: 11px; padding: 3px 10px; border-radius: 999px;
  letter-spacing: 0.5px;
}
.meta-pill.age {
  background: rgba(212, 168, 87, 0.15); color: #f4d77a;
  border: 1px solid rgba(212, 168, 87, 0.3);
}
.meta-pill.house {
  background: rgba(120, 80, 160, 0.15); color: #c8a8e0;
  border: 1px solid rgba(120, 80, 160, 0.3);
}
.meta-pill.blood {
  background: rgba(160, 60, 60, 0.15); color: #e0a8a8;
  border: 1px solid rgba(160, 60, 60, 0.3);
}
.meta-pill.group {
  background: rgba(60, 100, 160, 0.15); color: #a8c8e0;
  border: 1px solid rgba(60, 100, 160, 0.3);
}
.char-role {
  font-size: 13.5px; color: #c8bda5; line-height: 1.7;
}
.char-age-note {
  font-size: 12px; color: #8a7e6a; margin-top: 8px;
  font-style: italic;
}
.char-age-note em {
  color: #d4a857; font-style: normal; font-weight: 600;
}
.char-ref-badge {
  background: rgba(212, 168, 87, 0.1);
  border: 1px solid rgba(212, 168, 87, 0.3);
  border-radius: 10px; padding: 12px 16px; text-align: center;
  min-width: 180px;
}
@media (max-width: 700px) { .char-ref-badge { min-width: 0; } }
.ref-label {
  font-size: 10px; color: #8a7e6a;
  letter-spacing: 1.2px; text-transform: uppercase; margin-bottom: 4px;
}
.ref-name {
  font-size: 13px; color: #f4d77a; font-weight: 600; line-height: 1.4;
}

/* === IMAGE WIDGET === */
.img-widget {
  margin: 0 28px; padding: 16px 0;
  border-bottom: 1px solid rgba(212, 168, 87, 0.1);
}
.img-widget-header {
  display: flex; align-items: center; gap: 8px; margin-bottom: 12px;
}
.widget-icon { font-size: 14px; }
.widget-label {
  font-size: 12px; color: #b8ad95; letter-spacing: 0.5px;
}
.img-grid {
  display: grid; gap: 8px;
}
.img-grid.count-1 { grid-template-columns: 1fr; max-width: 280px; }
.img-grid.count-2 { grid-template-columns: repeat(2, 1fr); }
.img-grid.count-3 { grid-template-columns: repeat(3, 1fr); }
.img-cell {
  position: relative; aspect-ratio: 3/4; overflow: hidden;
  border-radius: 8px; cursor: pointer;
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(212, 168, 87, 0.15);
  transition: transform 0.3s, border-color 0.3s;
}
.img-cell:hover {
  transform: scale(1.02);
  border-color: rgba(212, 168, 87, 0.5);
}
.img-cell img {
  width: 100%; height: 100%; object-fit: cover; display: block;
  transition: transform 0.5s;
}
.img-cell:hover img { transform: scale(1.05); }
.img-cell.img-error::after {
  content: '⚠ Ảnh không tải được'; position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center;
  font-size: 12px; color: #8a7e6a; padding: 8px; text-align: center;
}
.img-widget-footer {
  margin-top: 8px; font-size: 11px; color: #6a604f;
}

/* === CHAR BODY === */
.char-body { padding: 24px 28px; }
.char-section { margin-bottom: 24px; }
.char-section:last-child { margin-bottom: 0; }
.section-title {
  font-size: 14px; color: #d4a857; margin-bottom: 10px;
  font-weight: 700; letter-spacing: 0.3px;
}
.char-text {
  font-size: 14px; color: #c8bda5; line-height: 1.8;
}
.arc-role-text {
  font-style: italic; color: #b8ad95;
  background: rgba(212, 168, 87, 0.04);
  padding: 12px 16px; border-left: 3px solid #d4a857;
  border-radius: 0 8px 8px 0;
}

/* === APPEARANCE GRID === */
.appearance-grid {
  display: grid; grid-template-columns: 1fr; gap: 10px;
}
.appr-row {
  display: grid; grid-template-columns: 120px 1fr; gap: 16px;
  padding: 10px 14px; background: rgba(0, 0, 0, 0.2);
  border-radius: 8px; border-left: 2px solid rgba(212, 168, 87, 0.3);
}
@media (max-width: 600px) {
  .appr-row { grid-template-columns: 1fr; gap: 4px; }
}
.appr-label {
  font-size: 11px; color: #d4a857; font-weight: 600;
  letter-spacing: 1px; text-transform: uppercase;
  padding-top: 2px;
}
.appr-text {
  font-size: 13.5px; color: #c8bda5; line-height: 1.7;
}

/* === ARC PROPOSAL === */
.arc-proposal {
  background: linear-gradient(180deg, rgba(80, 30, 30, 0.15) 0%, rgba(10, 6, 18, 0.4) 100%);
  border: 1px solid rgba(160, 60, 60, 0.3);
  border-radius: 20px; padding: 48px;
}
.arc-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 32px;
  margin-bottom: 32px;
}
@media (max-width: 900px) { .arc-grid { grid-template-columns: 1fr; } }
.arc-column-title {
  font-size: 18px; color: #f4d77a; margin-bottom: 16px;
  font-weight: 700; padding-bottom: 10px;
  border-bottom: 1px solid rgba(212, 168, 87, 0.25);
}
.arc-list {
  list-style: none; padding: 0; counter-reset: arc-counter;
}
.arc-list li {
  counter-increment: arc-counter;
  background: rgba(0, 0, 0, 0.25);
  border-left: 3px solid #d4a857;
  border-radius: 0 8px 8px 0;
  padding: 12px 16px; margin-bottom: 10px;
  display: grid; grid-template-columns: 1fr; gap: 4px;
  position: relative;
}
.arc-list li::before {
  content: counter(arc-counter);
  position: absolute; top: 12px; right: 16px;
  font-size: 11px; color: #8a7e6a; font-weight: 700;
  background: rgba(212, 168, 87, 0.15);
  width: 22px; height: 22px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
}
.arc-list li.bonus { border-left-color: #8a7e6a; }
.arc-name {
  font-size: 13.5px; font-weight: 700; color: #f4d77a;
}
.arc-desc {
  font-size: 12.5px; color: #b8ad95; line-height: 1.6;
}
.arc-bonus {
  background: rgba(255, 255, 255, 0.02);
  border: 1px solid rgba(180, 140, 80, 0.1);
  border-radius: 12px; padding: 24px;
}
.arc-list.bonus {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 10px;
}
.arc-list.bonus li { margin-bottom: 0; }

/* === OUTLINE LINK CARD (Part E) === */
.outline-link-card {
  display: grid; grid-template-columns: 80px 1fr; gap: 24px;
  background: linear-gradient(180deg, rgba(80, 30, 100, 0.15) 0%, rgba(10, 6, 18, 0.4) 100%);
  border: 1px solid rgba(180, 100, 200, 0.3);
  border-radius: 16px; padding: 32px;
  align-items: center;
}
@media (max-width: 700px) { .outline-link-card { grid-template-columns: 1fr; text-align: center; } }
.outline-link-icon {
  font-size: 56px; text-align: center;
  filter: drop-shadow(0 0 20px rgba(180, 100, 200, 0.4));
}
.outline-link-title {
  font-size: 22px; font-weight: 800; color: #f4d77a;
  margin-bottom: 8px;
  font-family: 'SF Mono', Monaco, monospace;
}
.outline-link-desc {
  font-size: 14px; color: #c8bda5; line-height: 1.8;
  margin-bottom: 16px;
}
.outline-link-desc code {
  background: rgba(212, 168, 87, 0.15);
  color: #f4d77a; padding: 2px 6px; border-radius: 3px;
  font-family: 'SF Mono', Monaco, monospace; font-size: 13px;
}
.outline-link-actions {
  display: flex; gap: 12px; flex-wrap: wrap;
}
.outline-btn {
  display: inline-block;
  padding: 10px 18px;
  border-radius: 8px;
  text-decoration: none;
  font-size: 14px; font-weight: 600;
  transition: all 0.2s;
}
.outline-btn.primary {
  background: linear-gradient(135deg, #d4a857 0%, #b88a3a 100%);
  color: #0a0612;
}
.outline-btn.primary:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 16px rgba(212, 168, 87, 0.4);
}
.outline-btn.secondary {
  background: rgba(212, 168, 87, 0.1);
  border: 1px solid rgba(212, 168, 87, 0.4);
  color: #f4d77a;
}
.outline-btn.secondary:hover {
  background: rgba(212, 168, 87, 0.2);
}

/* === FOOTER === */
.footer {
  border-top: 1px solid rgba(212, 168, 87, 0.15);
  padding: 32px 24px; margin-top: 80px;
}
.footer-inner {
  max-width: 1400px; margin: 0 auto; text-align: center;
  font-size: 12px; color: #6a604f; line-height: 1.8;
}

/* === LIGHTBOX === */
.lightbox {
  position: fixed; inset: 0; z-index: 9999;
  background: rgba(0, 0, 0, 0.92);
  display: flex; align-items: center; justify-content: center;
  padding: 40px; cursor: pointer;
}
.lightbox[hidden] { display: none; }
.lightbox img {
  max-width: 90%; max-height: 90vh; object-fit: contain;
  border-radius: 8px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
}
.lightbox-close {
  position: absolute; top: 20px; right: 30px;
  font-size: 48px; color: #f4d77a; cursor: pointer;
  font-weight: 300; line-height: 1;
}
"""

JS = """
// Lightbox
function openLightbox(url) {
  var lb = document.getElementById('lightbox');
  var img = document.getElementById('lightbox-img');
  img.src = url;
  lb.hidden = false;
  document.body.style.overflow = 'hidden';
}
function closeLightbox() {
  var lb = document.getElementById('lightbox');
  lb.hidden = true;
  document.body.style.overflow = '';
}
document.addEventListener('click', function(e) {
  var cell = e.target.closest('.img-cell');
  if (cell && !cell.classList.contains('img-error')) {
    var url = cell.getAttribute('data-img-url');
    if (url) openLightbox(url);
  }
  if (e.target.id === 'lightbox') closeLightbox();
});
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') closeLightbox();
});
"""


def main():
    html_content = build_html()
    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        f.write(html_content)
    size = os.path.getsize(OUT_PATH)
    print(f"✓ HTML written: {OUT_PATH}")
    print(f"  Size: {size:,} bytes ({size/1024:.1f} KB)")
    # Count characters
    print(f"  Family characters: {len(FAMILY_CHARACTERS)}")
    print(f"  Other characters: {len(OTHER_CHARACTERS)}")
    print(f"  Total: {len(FAMILY_CHARACTERS) + len(OTHER_CHARACTERS)}")


if __name__ == "__main__":
    main()
