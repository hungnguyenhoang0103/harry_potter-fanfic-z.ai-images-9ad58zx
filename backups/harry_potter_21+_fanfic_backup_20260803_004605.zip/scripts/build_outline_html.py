#!/usr/bin/env python3
"""
Build hp_story_outline.html — Story Outline with TOC navigation.
Structure: ARC > Chương (tên tùy chọn) > Phần
Features:
- TOC sidebar (auto-generated from headings)
- Status badges (draft/writing/done)
- Copy block button for each section
- Character tracking table
- Generic structure (can be reused for other stories)
"""
import json
import os
import html
from datetime import datetime

OUT_PATH = "/home/z/my-project/download/hp_story_outline.html"

# Story outline data — flexible structure
# Each ARC has: name, info, chapters[]
# Each chapter has: name (tùy chọn), parts[]
# Each part has: id, title, summary, status, characters[], word_count
STORY_OUTLINE = {
    "story_title": "Harry Potter — Fanfic 21+",
    "story_subtitle": "Arc & Chương Outline",
    "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M"),
    "arcs": [
        {
            "id": "arc_1",
            "name": "ARC 1: Khởi Đầu Hogwarts",
            "info": {
                "time": "Hè năm Harry 16 tuổi — mùa hè trước khi nhập học",
                "location": "Godric's Hollow · Diagon Alley · Hogwarts Express · Hogwarts",
                "main_characters": ["Harry Potter", "Lily Potter", "Euphemia Potter", "Hermione Granger"],
                "summary": "Harry nhận thư mời Hogwarts, gặp lại mẹ ruột Lily (hồi sinh qua huyết thuật), bà nội Euphemia trao di sản Potter, lên tàu gặp Hermione. Khởi đầu mạch dục vọng gia tộc.",
            },
            "chapters": [
                {
                    "id": "arc1_ch1",
                    "name": "Chương 1: Lá Thư Từ Hogwarts",
                    "parts": [
                        {
                            "id": "arc1_ch1_p1",
                            "title": "Phần 1 — Bối cảnh & tâm lý",
                            "summary": "Harry 16 tuổi tại số 4 Privet Drive, nhận thư mời Hogwarts. Petunia dì phản ứng kỳ lạ. Bối cảnh tuổi thơ mồ côi, khát khao tình mẫu tử.",
                            "status": "draft",
                            "characters": ["Harry Potter", "Petunia Dursley"],
                            "word_count": 0,
                        },
                        {
                            "id": "arc1_ch1_p2",
                            "title": "Phần 2 — Diagon Alley & gặp Lily",
                            "summary": "Harry đến Diagon Alley, gặp Lily Potter (mẹ ruột hồi sinh). Lần đầu gặp lại, cảm xúc bùng nổ. Cảnh dạo đầu.",
                            "status": "draft",
                            "characters": ["Harry Potter", "Lily Potter", "Madam Malkin"],
                            "word_count": 0,
                        },
                        {
                            "id": "arc1_ch1_p3",
                            "title": "Phần 3 — Cảnh sex đầu tiên với Lily",
                            "summary": "Cảnh sex chi tiết giữa Harry và Lily. Dục vọng huyết thuật bùng nổ.",
                            "status": "draft",
                            "characters": ["Harry Potter", "Lily Potter"],
                            "word_count": 0,
                        },
                        {
                            "id": "arc1_ch1_p4",
                            "title": "Phần 4 — Aftercare & chuyển tiếp",
                            "summary": "Aftercare giữa Lily và Harry. Bà nội Euphemia xuất hiện, mời Harry về Potter Manor.",
                            "status": "draft",
                            "characters": ["Harry Potter", "Lily Potter", "Euphemia Potter"],
                            "word_count": 0,
                        },
                    ],
                },
                {
                    "id": "arc1_ch2",
                    "name": "Chương 2: Potter Manor",
                    "parts": [
                        {
                            "id": "arc1_ch2_p1",
                            "title": "Phần 1 — Bà nội kiểm tra",
                            "summary": "Euphemia đưa Harry về Potter Manor, kiểm tra 'sự nam nhân' của cháu. Trao di sản Potter.",
                            "status": "draft",
                            "characters": ["Harry Potter", "Euphemia Potter"],
                            "word_count": 0,
                        },
                        {
                            "id": "arc1_ch2_p2",
                            "title": "Phần 2 — Cảnh sex với Euphemia",
                            "summary": "Dục vọng bùng nổ giữa bà nội và cháu trai. Arc gia tộc Potter bắt đầu.",
                            "status": "draft",
                            "characters": ["Harry Potter", "Euphemia Potter"],
                            "word_count": 0,
                        },
                        {
                            "id": "arc1_ch2_p3",
                            "title": "Phần 3 — Lily tham gia",
                            "summary": "Lily bắt gặp, thay vì giận dữ, nàng tham gia. Cảnh some mẹ-con.",
                            "status": "draft",
                            "characters": ["Harry Potter", "Lily Potter", "Euphemia Potter"],
                            "word_count": 0,
                        },
                    ],
                },
                {
                    "id": "arc1_ch3",
                    "name": "Chương 3: Tàu Hogwarts & Hermione",
                    "parts": [
                        {
                            "id": "arc1_ch3_p1",
                            "title": "Phần 1 — Tàu Express",
                            "summary": "Harry lên tàu Hogwarts Express, gặp Hermione Granger. Cảm xúc tuổi teen.",
                            "status": "draft",
                            "characters": ["Harry Potter", "Hermione Granger", "Ron Weasley"],
                            "word_count": 0,
                        },
                        {
                            "id": "arc1_ch3_p2",
                            "title": "Phần 2 — Foreplay trên tàu",
                            "summary": "Hermione và Harry tìm phòng riêng, dạo đầu.",
                            "status": "draft",
                            "characters": ["Harry Potter", "Hermione Granger"],
                            "word_count": 0,
                        },
                        {
                            "id": "arc1_ch3_p3",
                            "title": "Phần 3 — Cảnh sex với Hermione",
                            "summary": "Lần đầu tuổi teen, dục vọng tuổi 16-18.",
                            "status": "draft",
                            "characters": ["Harry Potter", "Hermione Granger"],
                            "word_count": 0,
                        },
                    ],
                },
            ],
        },
        {
            "id": "arc_2",
            "name": "ARC 2: Weasley & Burrow",
            "info": {
                "time": "Cuối hè — trước khi vào Hogwarts",
                "location": "The Burrow · Quidditch World Cup",
                "main_characters": ["Harry Potter", "Molly Weasley", "Ginny Weasley", "Fleur Delacour", "Victoire Weasley"],
                "summary": "Harry đến thăm Burrow. Molly chăm sóc Harry bị thương, Ginny chủ động, Fleur quyến rũ kiểu Pháp. Arc gia tộc Weasley bùng nổ.",
            },
            "chapters": [],
        },
    ],
    "character_tracking": [
        {"name": "Lily Potter", "arcs": "ARC 1 Ch 1-2", "scenes": 0, "last_seen": "—"},
        {"name": "Euphemia Potter", "arcs": "ARC 1 Ch 1-2", "scenes": 0, "last_seen": "—"},
        {"name": "Petunia Dursley", "arcs": "ARC 1 Ch 1", "scenes": 0, "last_seen": "—"},
        {"name": "Madam Malkin", "arcs": "ARC 1 Ch 1", "scenes": 0, "last_seen": "—"},
        {"name": "Hermione Granger", "arcs": "ARC 1 Ch 3", "scenes": 0, "last_seen": "—"},
        {"name": "Ron Weasley", "arcs": "ARC 1 Ch 3", "scenes": 0, "last_seen": "—"},
        {"name": "Molly Weasley", "arcs": "—", "scenes": 0, "last_seen": "—"},
        {"name": "Ginny Weasley", "arcs": "—", "scenes": 0, "last_seen": "—"},
        {"name": "Fleur Delacour", "arcs": "—", "scenes": 0, "last_seen": "—"},
    ],
}


def esc(s):
    return html.escape(str(s)) if s else ""


def status_badge(status):
    colors = {
        "draft": ("#6a604f", "rgba(106,96,79,0.15)"),
        "writing": ("#d4a857", "rgba(212,168,87,0.2)"),
        "done": ("#4a9d5a", "rgba(74,157,90,0.2)"),
    }
    color, bg = colors.get(status, colors["draft"])
    return f'<span class="status-badge" style="color:{color};background:{bg};">{esc(status)}</span>'


def render_part(part):
    chars = ", ".join(part.get("characters", []))
    copy_text = f'Viết tiếp {part["title"]} của {part["id"].rsplit("_",2)[0]} (ARC: {part["id"].split("_")[0]})'
    return f"""
    <div class="part" id="{esc(part['id'])}">
      <div class="part-header">
        <h4 class="part-title">{esc(part['title'])}</h4>
        {status_badge(part['status'])}
      </div>
      <div class="part-body">
        <p class="part-summary">{esc(part['summary'])}</p>
        <div class="part-meta">
          <span class="meta-item"><strong>Nhân vật:</strong> {esc(chars)}</span>
          <span class="meta-item"><strong>Word count:</strong> {part['word_count']:,}</span>
        </div>
        <div class="part-actions">
          <button class="copy-btn" data-copy-text="{esc(copy_text)}" onclick="copyToClipboard(this)">
            📋 Copy prompt
          </button>
          <a href="#" class="edit-status-link" onclick="updateStatus('{esc(part['id'])}');return false;">
            ✏️ Đổi status
          </a>
        </div>
      </div>
    </div>
    """


def render_chapter(chapter):
    parts_html = "".join(render_part(p) for p in chapter.get("parts", []))
    n_parts = len(chapter.get("parts", []))
    done_parts = sum(1 for p in chapter.get("parts", []) if p["status"] == "done")
    return f"""
    <section class="chapter" id="{esc(chapter['id'])}">
      <header class="chapter-header">
        <h3 class="chapter-title">{esc(chapter['name'])}</h3>
        <span class="chapter-progress">{done_parts}/{n_parts} parts done</span>
      </header>
      <div class="parts-list">
        {parts_html}
      </div>
    </section>
    """


def render_arc(arc):
    chapters_html = "".join(render_chapter(c) for c in arc.get("chapters", []))
    info = arc.get("info", {})
    main_chars = ", ".join(info.get("main_characters", []))

    return f"""
    <section class="arc" id="{esc(arc['id'])}">
      <header class="arc-header">
        <h2 class="arc-title">{esc(arc['name'])}</h2>
      </header>
      <div class="arc-info">
        <div class="info-row"><span class="info-key">⏰ Thời gian</span><span class="info-val">{esc(info.get('time', '—'))}</span></div>
        <div class="info-row"><span class="info-key">📍 Địa điểm</span><span class="info-val">{esc(info.get('location', '—'))}</span></div>
        <div class="info-row"><span class="info-key">👤 Nhân vật chính</span><span class="info-val">{esc(main_chars)}</span></div>
        <div class="info-row"><span class="info-key">📝 Tóm tắt</span><span class="info-val">{esc(info.get('summary', '—'))}</span></div>
      </div>
      <div class="chapters-list">
        {chapters_html}
      </div>
    </section>
    """


def render_toc(outline):
    """Render table of contents sidebar."""
    items = []
    for arc in outline["arcs"]:
        children = []
        for ch in arc.get("chapters", []):
            children.append(f'<a href="#{esc(ch["id"])}" class="toc-chapter">{esc(ch["name"])}</a>')
        children_html = "".join(children)
        items.append(f"""
        <div class="toc-arc">
          <a href="#{esc(arc['id'])}" class="toc-arc-link">{esc(arc['name'])}</a>
          <div class="toc-children">{children_html}</div>
        </div>
        """)
    return "".join(items)


def render_character_tracking(tracking):
    rows = ""
    for t in tracking:
        rows += f"""
        <tr>
          <td>{esc(t['name'])}</td>
          <td>{esc(t['arcs'])}</td>
          <td>{t['scenes']}</td>
          <td>{esc(t['last_seen'])}</td>
        </tr>
        """
    return rows


def build_html():
    outline = STORY_OUTLINE
    toc_html = render_toc(outline)
    arcs_html = "".join(render_arc(arc) for arc in outline["arcs"])
    tracking_rows = render_character_tracking(outline["character_tracking"])

    return f"""<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{esc(outline['story_title'])} · Story Outline</title>
<style>{CSS}</style>
</head>
<body>

<nav class="top-nav">
  <div class="nav-inner">
    <a href="#top" class="nav-brand">📖 Story Outline</a>
    <div class="nav-links">
      <a href="#top">Overview</a>
      <a href="#character-tracking">Character Tracking</a>
      <a href="../download/hp_bible.html" target="_blank">↗ Character Bible</a>
    </div>
    <div class="nav-stats">
      <span>Updated: {esc(outline['last_updated'])}</span>
    </div>
  </div>
</nav>

<div class="layout">

<aside class="toc-sidebar">
  <div class="toc-header">
    <h3>📑 Mục Lục</h3>
    <button class="toc-toggle" onclick="toggleTOC()">◀</button>
  </div>
  <div class="toc-content">
    {toc_html}
  </div>
</aside>

<main class="main" id="top">

<header class="story-header">
  <h1 class="story-title">{esc(outline['story_title'])}</h1>
  <p class="story-subtitle">{esc(outline['story_subtitle'])}</p>
  <div class="story-meta">
    <span>Last updated: {esc(outline['last_updated'])}</span>
    <span>·</span>
    <span>{len(outline['arcs'])} ARCs</span>
    <span>·</span>
    <span>{sum(len(a.get('chapters',[])) for a in outline['arcs'])} chapters</span>
    <span>·</span>
    <span>{sum(len(c.get('parts',[])) for a in outline['arcs'] for c in a.get('chapters',[]))} parts</span>
  </div>
</header>

<section class="overview">
  <h2>📌 Tổng quan</h2>
  <p>Đây là file outline cho truyện <strong>{esc(outline['story_title'])}</strong>. File này duy trì cấu trúc ARC > Chương > Phần, với status tracking và copy-paste prompts để dễ dàng tiếp tục viết trong các session khác.</p>
  <p>Mỗi phần có nút <strong>📋 Copy prompt</strong> — click để copy prompt "Viết tiếp..." vào clipboard, paste vào cửa sổ AI khác để tiếp tục viết.</p>
  <p>File này được update tự động bởi <code>story-outline-manager</code> skill sau khi mỗi phần được viết xong.</p>
</section>

<section class="arcs-section">
  {arcs_html}
</section>

<section class="character-tracking" id="character-tracking">
  <h2>👥 Character Tracking</h2>
  <p>Bảng theo dõi nhân vật — số lần xuất hiện, ARC đã tham gia, lần cuối xuất hiện.</p>
  <table class="tracking-table">
    <thead>
      <tr>
        <th>Nhân vật</th>
        <th>ARCs</th>
        <th>Scenes</th>
        <th>Last seen</th>
      </tr>
    </thead>
    <tbody>
      {tracking_rows}
    </tbody>
  </table>
</section>

</main>
</div>

<div id="toast" class="toast" hidden>Copied!</div>

<script>{JS}</script>
</body>
</html>"""


CSS = """
* { margin: 0; padding: 0; box-sizing: border-box; }
html { scroll-behavior: smooth; scroll-padding-top: 80px; }
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Noto Sans', sans-serif;
  background: #0a0612;
  color: #e8e3d3;
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
}

/* === TOP NAV === */
.top-nav {
  position: sticky; top: 0; z-index: 100;
  background: rgba(10, 6, 18, 0.92);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(180, 140, 80, 0.25);
  padding: 12px 0;
}
.nav-inner {
  max-width: 1600px; margin: 0 auto; padding: 0 24px;
  display: flex; align-items: center; gap: 24px;
}
.nav-brand {
  font-weight: 800; color: #d4a857; text-decoration: none; font-size: 16px;
}
.nav-links { display: flex; gap: 18px; flex: 1; }
.nav-links a {
  color: #b8ad95; text-decoration: none; font-size: 14px;
  padding: 4px 0; border-bottom: 2px solid transparent;
  transition: color 0.2s, border-color 0.2s;
}
.nav-links a:hover { color: #e8d5a0; border-bottom-color: #d4a857; }
.nav-stats { font-size: 12px; color: #8a7e6a; }

/* === LAYOUT === */
.layout {
  display: grid;
  grid-template-columns: 280px 1fr;
  max-width: 1600px;
  margin: 0 auto;
  min-height: calc(100vh - 60px);
}
@media (max-width: 1000px) {
  .layout { grid-template-columns: 1fr; }
  .toc-sidebar { display: none; }
}

/* === TOC SIDEBAR === */
.toc-sidebar {
  position: sticky; top: 60px;
  height: calc(100vh - 60px);
  overflow-y: auto;
  padding: 24px 16px;
  background: rgba(20, 12, 35, 0.4);
  border-right: 1px solid rgba(212, 168, 87, 0.15);
}
.toc-header {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid rgba(212, 168, 87, 0.2);
}
.toc-header h3 {
  font-size: 14px; color: #d4a857; font-weight: 700;
  letter-spacing: 1px; text-transform: uppercase;
}
.toc-toggle {
  background: none; border: 1px solid rgba(212, 168, 87, 0.3);
  color: #b8ad95; cursor: pointer; padding: 2px 8px;
  border-radius: 4px; font-size: 12px;
}
.toc-content {
  font-size: 13px;
}
.toc-arc {
  margin-bottom: 16px;
}
.toc-arc-link {
  display: block;
  color: #f4d77a; text-decoration: none;
  font-weight: 600; padding: 4px 8px;
  border-radius: 4px;
  transition: background 0.2s;
}
.toc-arc-link:hover { background: rgba(212, 168, 87, 0.1); }
.toc-children {
  margin-left: 12px;
  border-left: 2px solid rgba(212, 168, 87, 0.2);
  padding-left: 8px;
  margin-top: 4px;
}
.toc-chapter {
  display: block;
  color: #b8ad95; text-decoration: none;
  font-size: 12px; padding: 3px 6px;
  border-radius: 3px;
  transition: color 0.2s, background 0.2s;
}
.toc-chapter:hover { color: #e8d5a0; background: rgba(212, 168, 87, 0.08); }

/* === MAIN === */
.main { padding: 40px 48px; max-width: 1100px; }

/* === STORY HEADER === */
.story-header {
  margin-bottom: 48px;
  padding: 32px;
  background: linear-gradient(180deg, rgba(20,12,35,0.6) 0%, rgba(10,6,18,0.4) 100%);
  border: 1px solid rgba(212, 168, 87, 0.25);
  border-radius: 16px;
}
.story-title {
  font-size: 36px; font-weight: 900;
  background: linear-gradient(135deg, #f4d77a 0%, #d4a857 100%);
  -webkit-background-clip: text; background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 8px;
}
.story-subtitle {
  font-size: 16px; color: #b8ad95; margin-bottom: 16px;
}
.story-meta {
  font-size: 13px; color: #8a7e6a; display: flex; gap: 8px; flex-wrap: wrap;
}

/* === OVERVIEW === */
.overview {
  margin-bottom: 48px;
  padding: 24px;
  background: rgba(255, 255, 255, 0.025);
  border: 1px solid rgba(212, 168, 87, 0.15);
  border-radius: 12px;
}
.overview h2 {
  font-size: 18px; color: #d4a857; margin-bottom: 12px;
}
.overview p {
  font-size: 14px; color: #c8bda5; margin-bottom: 10px; line-height: 1.8;
}
.overview code {
  background: rgba(212, 168, 87, 0.15);
  color: #f4d77a; padding: 2px 6px; border-radius: 3px;
  font-family: 'SF Mono', Monaco, monospace; font-size: 13px;
}

/* === ARC === */
.arc {
  margin-bottom: 56px;
  background: linear-gradient(180deg, rgba(20,12,35,0.5) 0%, rgba(10,6,18,0.3) 100%);
  border: 1px solid rgba(212, 168, 87, 0.2);
  border-radius: 16px;
  overflow: hidden;
}
.arc-header {
  padding: 20px 24px;
  background: linear-gradient(90deg, rgba(212, 168, 87, 0.08) 0%, transparent 100%);
  border-bottom: 1px solid rgba(212, 168, 87, 0.2);
}
.arc-title {
  font-size: 22px; font-weight: 800; color: #f4d77a;
}
.arc-info {
  padding: 16px 24px;
  background: rgba(0, 0, 0, 0.2);
  border-bottom: 1px solid rgba(212, 168, 87, 0.1);
}
.info-row {
  display: grid; grid-template-columns: 160px 1fr; gap: 12px;
  padding: 6px 0;
  font-size: 13px;
}
.info-key { color: #8a7e6a; font-weight: 600; }
.info-val { color: #c8bda5; }

/* === CHAPTER === */
.chapter {
  padding: 24px;
  border-bottom: 1px solid rgba(212, 168, 87, 0.1);
}
.chapter:last-child { border-bottom: none; }
.chapter-header {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 20px;
  padding-bottom: 12px;
  border-bottom: 1px dashed rgba(212, 168, 87, 0.2);
}
.chapter-title {
  font-size: 18px; font-weight: 700; color: #e8d5a0;
}
.chapter-progress {
  font-size: 12px; color: #8a7e6a;
  background: rgba(212, 168, 87, 0.1);
  padding: 4px 10px; border-radius: 999px;
}

/* === PART === */
.part {
  background: rgba(0, 0, 0, 0.2);
  border-left: 3px solid #d4a857;
  border-radius: 0 8px 8px 0;
  padding: 16px 20px;
  margin-bottom: 12px;
  transition: border-color 0.3s;
}
.part:hover { border-left-color: #f4d77a; }
.part-header {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 10px;
}
.part-title {
  font-size: 14px; font-weight: 600; color: #e8d5a0;
}
.status-badge {
  font-size: 10px; padding: 3px 10px; border-radius: 999px;
  text-transform: uppercase; letter-spacing: 1px; font-weight: 700;
  border: 1px solid currentColor;
}
.part-body { font-size: 13px; }
.part-summary {
  color: #b8ad95; line-height: 1.7; margin-bottom: 10px;
}
.part-meta {
  display: flex; gap: 20px; flex-wrap: wrap;
  font-size: 12px; color: #8a7e6a; margin-bottom: 12px;
}
.part-meta strong { color: #b8ad95; }
.part-actions {
  display: flex; gap: 12px; align-items: center;
  padding-top: 8px;
  border-top: 1px dashed rgba(212, 168, 87, 0.15);
}
.copy-btn {
  background: rgba(212, 168, 87, 0.15);
  border: 1px solid rgba(212, 168, 87, 0.4);
  color: #f4d77a;
  padding: 6px 12px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 12px;
  transition: all 0.2s;
}
.copy-btn:hover {
  background: rgba(212, 168, 87, 0.3);
  color: #fff;
}
.edit-status-link {
  color: #8a7e6a; text-decoration: none;
  font-size: 12px;
  transition: color 0.2s;
}
.edit-status-link:hover { color: #d4a857; }

/* === CHARACTER TRACKING === */
.character-tracking {
  margin-top: 56px;
  padding: 24px;
  background: rgba(255, 255, 255, 0.025);
  border: 1px solid rgba(212, 168, 87, 0.15);
  border-radius: 12px;
}
.character-tracking h2 {
  font-size: 20px; color: #d4a857; margin-bottom: 8px;
}
.character-tracking > p {
  font-size: 13px; color: #8a7e6a; margin-bottom: 16px;
}
.tracking-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}
.tracking-table th {
  text-align: left;
  padding: 10px 12px;
  background: rgba(212, 168, 87, 0.1);
  color: #d4a857;
  font-weight: 700;
  border-bottom: 1px solid rgba(212, 168, 87, 0.3);
}
.tracking-table td {
  padding: 10px 12px;
  border-bottom: 1px solid rgba(212, 168, 87, 0.1);
  color: #c8bda5;
}
.tracking-table tr:hover td { background: rgba(212, 168, 87, 0.05); }

/* === TOAST === */
.toast {
  position: fixed; bottom: 32px; left: 50%; transform: translateX(-50%);
  background: #4a9d5a; color: #fff;
  padding: 12px 24px; border-radius: 8px;
  font-size: 14px; font-weight: 600;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
  z-index: 9999;
  transition: opacity 0.3s;
}
.toast[hidden] { display: none; }
"""

JS = """
function copyToClipboard(btn) {
  var text = btn.getAttribute('data-copy-text');
  navigator.clipboard.writeText(text).then(function() {
    showToast('✓ Copied: ' + text.substring(0, 60) + '...');
  }).catch(function() {
    // Fallback
    var ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showToast('✓ Copied (fallback)');
  });
}

function showToast(msg) {
  var toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.hidden = false;
  setTimeout(function() { toast.hidden = true; }, 2500);
}

function toggleTOC() {
  var sidebar = document.querySelector('.toc-sidebar');
  sidebar.classList.toggle('collapsed');
}

function updateStatus(partId) {
  // This is a placeholder — in real workflow, this would call the agent
  var newStatus = prompt('Đổi status cho ' + partId + '\\n(draft / writing / done):');
  if (newStatus && ['draft', 'writing', 'done'].includes(newStatus)) {
    showToast('⚠ Để update status thực, dùng story-outline-manager skill. Mở README để xem hướng dẫn.');
  }
}
"""


def main():
    html_content = build_html()
    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        f.write(html_content)
    size = os.path.getsize(OUT_PATH)
    print(f"✓ HTML written: {OUT_PATH}")
    print(f"  Size: {size:,} bytes ({size/1024:.1f} KB)")
    arcs = STORY_OUTLINE["arcs"]
    chapters = sum(len(a.get("chapters", [])) for a in arcs)
    parts = sum(len(c.get("parts", [])) for a in arcs for c in a.get("chapters", []))
    print(f"  Arcs: {len(arcs)}, Chapters: {chapters}, Parts: {parts}")


if __name__ == "__main__":
    main()
