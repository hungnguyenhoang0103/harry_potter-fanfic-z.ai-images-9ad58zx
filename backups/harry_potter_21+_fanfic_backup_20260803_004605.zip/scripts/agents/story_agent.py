#!/usr/bin/env python3
"""
story_agent.py — Story tracking agent (generic, config-driven).

Commands:
  save-part <part_id> [--word-count N] [--characters "A, B"] [--status done] [--story-file PATH]
  status <part_id> <draft|writing|done>
  list

Usage:
  python3 scripts/agents/story_agent.py save-part arc1_ch1_p1 --word-count 12500 --characters "Harry, Lily" --status done --story-file /tmp/p1.txt
  python3 scripts/agents/story_agent.py list
"""
import argparse, sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
from shared import *

def cmd_save_part(config, args):
    outline_path = resolve_path(config, "outline_data")
    if not os.path.exists(outline_path):
        output({"status": "error", "message": "Outline data not found"})
        return
    
    with file_lock("outline"):
        with open(outline_path) as f:
            outline = json.load(f)
        
        found = False
        for arc in outline.get("arcs", []):
            for ch in arc.get("chapters", []):
                for p in ch.get("parts", []):
                    if p["id"] == args.part_id:
                        found = True
                        if args.status: p["status"] = args.status
                        if args.word_count is not None: p["word_count"] = args.word_count
                        if args.characters: p["characters"] = [c.strip() for c in args.characters.split(",")]
                        if args.story_file:
                            if args.story_file == "-": p["story_content"] = sys.stdin.read()
                            elif os.path.exists(args.story_file):
                                with open(args.story_file, encoding="utf-8") as sf: p["story_content"] = sf.read()
        
        if not found:
            output({"status": "error", "message": f"Part '{args.part_id}' not found"})
            return
        
        with open(outline_path, 'w') as f:
            json.dump(outline, f, ensure_ascii=False, indent=2)
    
    results = rebuild_html(config, "outline")
    output({"status": "ok", "part_id": args.part_id, "word_count": args.word_count, "rebuilt": results})

def cmd_status(config, args):
    outline_path = resolve_path(config, "outline_data")
    if not os.path.exists(outline_path):
        output({"status": "error", "message": "Outline data not found"})
        return
    
    with file_lock("outline"):
        with open(outline_path) as f:
            outline = json.load(f)
        for arc in outline.get("arcs", []):
            for ch in arc.get("chapters", []):
                for p in ch.get("parts", []):
                    if p["id"] == args.part_id:
                        p["status"] = args.status
        with open(outline_path, 'w') as f:
            json.dump(outline, f, ensure_ascii=False, indent=2)
    output({"status": "ok", "part_id": args.part_id, "new_status": args.status})

def cmd_list(config, args):
    outline_path = resolve_path(config, "outline_data")
    if not os.path.exists(outline_path):
        output({"status": "error", "message": "No outline data"})
        return
    with open(outline_path) as f:
        outline = json.load(f)
    parts = []
    for arc in outline.get("arcs", []):
        for ch in arc.get("chapters", []):
            for p in ch.get("parts", []):
                parts.append({"id": p["id"], "title": p["title"], "status": p.get("status","draft"), "word_count": p.get("word_count",0), "chapter": ch["name"], "arc": arc["name"]})
    output({"parts": parts, "total": len(parts)})

def main():
    parser = argparse.ArgumentParser(description="Story Agent")
    sub = parser.add_subparsers(dest="command")
    p_sp = sub.add_parser("save-part"); p_sp.add_argument("part_id"); p_sp.add_argument("--word-count", type=int); p_sp.add_argument("--characters"); p_sp.add_argument("--status", choices=["draft","writing","done"]); p_sp.add_argument("--story-file")
    p_st = sub.add_parser("status"); p_st.add_argument("part_id"); p_st.add_argument("status", choices=["draft","writing","done"])
    sub.add_parser("list")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()
    
    config = load_config()
    if args.command == "save-part": cmd_save_part(config, args)
    elif args.command == "status": cmd_status(config, args)
    elif args.command == "list": cmd_list(config, args)
    else: parser.print_help()

if __name__ == "__main__": main()
