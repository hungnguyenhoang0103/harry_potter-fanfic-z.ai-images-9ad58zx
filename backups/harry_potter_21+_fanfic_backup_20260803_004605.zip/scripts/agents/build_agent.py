#!/usr/bin/env python3
"""
build_agent.py — Rebuild HTML files (generic, config-driven).

Commands:
  all       Rebuild all HTML files
  bible     Rebuild Bible HTML only
  outline   Rebuild Outline HTML only

Usage:
  python3 scripts/agents/build_agent.py all
"""
import argparse, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from shared import *

def main():
    parser = argparse.ArgumentParser(description="Build Agent")
    parser.add_argument("target", nargs="?", choices=["all", "bible", "outline"], default="all")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()
    
    config = load_config()
    results = rebuild_html(config, args.target)
    output({"status": "ok", "built": results})

if __name__ == "__main__": main()
