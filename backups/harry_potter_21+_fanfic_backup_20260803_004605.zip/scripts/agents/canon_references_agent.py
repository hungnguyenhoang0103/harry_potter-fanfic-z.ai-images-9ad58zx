#!/usr/bin/env python3
"""Canon References Agent — Build & manage HP canon reference.
Commands: build, remind, update-outline, list-events, search, list-arcs, list-foreshadowing, list-objects, list-locations, list-spells, list-creatures, list-themes, list-behind-scenes
"""
import argparse, json, os, sys, re
sys.path.insert(0, "/home/z/my-project/scripts")
from canon_data import *

PROJECT_ROOT = "/home/z/my-project"

def build_canon_html_file():
    out_path = f"{PROJECT_ROOT}/download/hp_canon_reference.html"
    sections = [
        ("books", "📖 7 Books Overview", render_books()),
        ("events", f"📅 Events Timeline ({len(CANON_EVENTS)} events)", render_events()),
        ("objects", f"🔮 Key Objects ({len(KEY_OBJECTS)})", render_objects()),
        ("locations", f"🗺️ Locations ({len(LOCATIONS)})", render_locations()),
        ("spells", f"✨ Spells & Magic ({len(SPELLS)})", render_spells()),
        ("creatures", f"🐉 Magical Creatures ({len(MAGICAL_CREATURES)})", render_creatures()),
        ("arcs", f"👤 Character Arcs ({len(CHARACTER_ARCS)})", render_arcs()),
        ("relationships", f"💕 Relationship Evolution ({len(RELATIONSHIP_EVOLUTION)})", render_relationships()),
        ("foreshadowing", f"🔮 Foreshadowing ({len(FORESHADOWING)})", render_foreshadowing()),
        ("themes", f"🎭 Themes & Symbolism ({len(THEMES)})", render_themes()),
        ("behind-scenes", f"🎬 Behind the Scenes ({len(BEHIND_SCENES)})", render_behind_scenes()),
    ]
    sections_html = "\n\n".join(f'<section class="section" id="{sid}"><h2>{title}</h2>{content}</section>' for sid, title, content in sections)
    nav_links = " · ".join(f'<a href="#{sid}">{title.split(" ", 1)[1] if " " in title else title}</a>' for sid, title, _ in sections)

    html = f"""<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Harry Potter · Canon Reference</title><style>{CANON_CSS}</style></head><body>
<nav class="top-nav"><div class="nav-inner"><a href="#top" class="nav-brand">📚 Canon Reference</a><div class="nav-links">{nav_links} · <a href="hp_bible.html" target="_blank">↗ Bible</a></div><div class="nav-search"><input type="text" id="search-box" placeholder="🔍 Tìm..." oninput="performSearch(this.value)"/><button class="search-clear" id="search-clear" onclick="clearSearch()">×</button></div></div></nav>
<main class="main" id="top"><header class="page-header"><h1>📚 Harry Potter — Canon Reference (Expanded)</h1><p>{len(BOOKS)} books · {len(CANON_EVENTS)} events · {len(KEY_OBJECTS)} objects · {len(LOCATIONS)} locations · {len(SPELLS)} spells · {len(MAGICAL_CREATURES)} creatures · {len(CHARACTER_ARCS)} arcs · {len(RELATIONSHIP_EVOLUTION)} relationships · {len(FORESHADOWING)} foreshadowing · {len(THEMES)} themes · {len(BEHIND_SCENES)} behind-the-scenes</p></header>
{sections_html}</main><script>{CANON_JS}</script></body></html>"""
    with open(out_path, "w", encoding="utf-8") as f: f.write(html)
    print(f"  ✓ Written: {out_path} ({len(html):,} bytes)", flush=True)

def esc(s): import html; return html.escape(str(s)) if s else ""
def render_books():
    items = "".join(f'<div class="card"><h3>Book {b}: {BOOKS[b]["title"]}</h3><p class="muted">{BOOKS[b]["title_vn"]}</p><p class="muted">{BOOKS[b]["year"]} · Harry age {BOOKS[b]["harry_age"]}</p><p>{BOOKS[b]["summary"]}</p><p class="muted">Themes: {", ".join(BOOKS[b]["themes"])}</p><p class="muted">Key: {", ".join(BOOKS[b]["key_characters"][:5])}...</p></div>' for b in sorted(BOOKS.keys()))
    return f'<div class="grid-3">{items}</div>'

def render_events():
    by_book = {}
    for e in CANON_EVENTS: by_book.setdefault(e["book"], []).append(e)
    sections = ""
    for b in sorted(by_book.keys()):
        events = by_book[b]
        items = "".join(f'<div class="card event-{e.get("importance","medium")}"><div class="event-header"><span class="muted">{e["id"]}</span><span class="badge">{e.get("importance","?").upper()}</span></div><h4>{e["title"]}</h4><p class="muted">Ch {e.get("chapter","?")} · {e.get("date","?")} · {e.get("location","?")}</p><p>{e["description"]}</p><p class="muted">Chars: {", ".join(e.get("characters",[])[:5])}</p>{"<p class=muted>Spells: "+", ".join(e.get("spells",[]))+"</p>" if e.get("spells") else ""}{"<p class=muted>Objects: "+", ".join(e.get("objects",[]))+"</p>" if e.get("objects") else ""}</div>' for e in events)
        sections += f'<h3>Book {b}: {BOOKS.get(b,{}).get("title","")} ({len(events)} events)</h3><div class="grid-2">{items}</div>'
    return sections

def render_objects():
    items = "".join(f'<div class="card"><h4>{v["name"]}</h4><p class="muted">{v["first_appearance"]}</p><p>{v["description"]}</p></div>' for v in KEY_OBJECTS.values())
    return f'<div class="grid-3">{items}</div>'

def render_locations():
    items = "".join(f'<div class="card"><h4>{v["name"]}</h4><p class="muted">{v["type"]}</p><p>{v["description"]}</p></div>' for v in LOCATIONS.values())
    return f'<div class="grid-3">{items}</div>'

def render_spells():
    items = "".join(f'<div class="card"><h4>{v["name"]}</h4><p class="muted">{v["type"]}</p><p>{v["effect"]}</p><p class="muted">First: {v["first_use"]}</p></div>' for v in SPELLS.values())
    return f'<div class="grid-3">{items}</div>'

def render_creatures():
    items = "".join(f'<div class="card"><h4>{v["name"]}</h4><p>{v["description"]}</p></div>' for v in MAGICAL_CREATURES.values())
    return f'<div class="grid-3">{items}</div>'

def render_arcs():
    items = ""
    for name, arcs in CHARACTER_ARCS.items():
        arc_items = "".join(f'<div class="arc-year"><h5>Book {b} ({BOOKS.get(b,{}).get("year","")})</h5><p>{arcs[b]}</p></div>' for b in sorted(arcs.keys()))
        items += f'<div class="card"><h3>{name}</h3>{arc_items}</div>'
    return f'<div class="grid-2">{items}</div>'

def render_relationships():
    items = "".join(f'<div class="card"><h4>{r["from"]} ↔ {r["to"]}</h4><p class="muted">Books: {", ".join(f"B{b}" for b in r["books"])}</p><p>{r["evolution"]}</p></div>' for r in RELATIONSHIP_EVOLUTION)
    return f'<div class="grid-2">{items}</div>'

def render_foreshadowing():
    items = "".join(f'<div class="card fs-card"><div class="fs-setup"><span class="badge">SETUP Book {f["setup_book"]}</span><p>{f["setup_event"]}</p></div><div class="fs-arrow">→</div><div class="fs-payoff"><span class="badge green">PAYOFF Book {f["payoff_book"]}</span><p>{f["payoff_event"]}</p></div></div>' for f in FORESHADOWING)
    return f'<div class="grid-2">{items}</div>'

def render_themes():
    items = "".join(f'<div class="card"><h3>Book {b}: {", ".join(THEMES[b]["main_themes"])}</h3><p>{THEMES[b]["analysis"]}</p></div>' for b in sorted(THEMES.keys()))
    return f'<div class="grid-2">{items}</div>'

def render_behind_scenes():
    items = "".join(f'<div class="card"><p class="muted">{f["category"]}</p><p>{f["fact"]}</p></div>' for f in BEHIND_SCENES)
    return f'<div class="grid-3">{items}</div>'

def cmd_build():
    print("Building canon reference...", flush=True)
    build_canon_html_file()
    # Patch build_html.py for Part F
    patch_build_html()
    # Rebuild bible
    print("  → Rebuilding hp_bible.html...", flush=True)
    os.system(f"cd {PROJECT_ROOT} && python3 scripts/build_html.py > /dev/null 2>&1")
    print("  ✓ Done", flush=True)

def patch_build_html():
    path = f"{PROJECT_ROOT}/scripts/build_html.py"
    with open(path, "r", encoding="utf-8") as f: content = f.read()
    if "Part F · Canon Reference" in content:
        print("    ℹ Already patched", flush=True); return
    part_f = '''
<section class="section" id="canon-reference-link">
  <header class="section-header">
    <h2 class="section-h2">Part F · Nguyên Tác Reference</h2>
    <p class="section-sub">7 books · 150 events · 25 objects · 27 locations · 21 spells · 20 creatures · Reference for staying true to canon</p>
  </header>
  <div class="outline-link-card">
    <div class="outline-link-icon">📚</div>
    <div class="outline-link-body">
      <h3 class="outline-link-title">hp_canon_reference.html</h3>
      <p class="outline-link-desc">Detailed canon reference: 7 books, 150 events, key objects, locations, spells, magical creatures, character arcs, relationship evolution, foreshadowing, themes, behind-the-scenes. Used by AI to bám sát nguyên tác.</p>
      <div class="outline-link-actions"><a href="hp_canon_reference.html" class="outline-btn primary" target="_blank">🔗 Mở Canon Reference</a></div>
    </div>
  </div>
</section>'''
    # Insert before </main>
    content = content.replace("</main>", part_f + "\n</main>", 1)
    # Add nav link
    content = content.replace('<a href="#story-outline-link">Outline</a>', '<a href="#story-outline-link">Outline</a>\n      <a href="#canon-reference-link">Canon</a>')
    with open(path, "w", encoding="utf-8") as f: f.write(content)
    print("    ✓ Patched build_html.py for Part F", flush=True)

def cmd_remind(part_id):
    m = re.match(r'arc(\d+)_ch(\d+)_p(\d+)', part_id)
    if not m: print(f"  ✗ Invalid part_id: {part_id}"); return False
    arc, ch = int(m.group(1)), int(m.group(2))
    book = arc
    prev = [e for e in CANON_EVENTS if e["book"] == book and e.get("chapter", 0) < ch]
    curr = [e for e in CANON_EVENTS if e["book"] == book and abs(e.get("chapter", 0) - ch) <= 1]
    nxt = [e for e in CANON_EVENTS if e["book"] == book and e.get("chapter", 0) > ch]
    print(f"\n{'='*60}\n📖 CANON REMINDER for {part_id}\n   Book {book} ({BOOKS.get(book,{}).get('title','?')})\n{'='*60}")
    if prev: print(f"\n⬅ PREVIOUS: {prev[-1]['title']}\n   {prev[-1]['description'][:200]}...")
    if curr: print(f"\n📍 CURRENT:"); [print(f"   • {e['title']}") for e in curr[:3]]
    if nxt: print(f"\n➡ NEXT: {nxt[0]['title']}\n   {nxt[0]['description'][:200]}...")
    if len(nxt) > 1: print(f"\n   Upcoming:"); [print(f"   • {e['title']}") for e in nxt[1:4]]
    print(f"\n{'='*60}")
    return True

def cmd_list_events(book=None, character=None, tag=None):
    events = CANON_EVENTS
    if book: events = [e for e in events if e["book"] == book]
    if character: cl = character.lower(); events = [e for e in events if any(cl in c.lower() for c in e.get("characters", []))]
    if tag: tl = tag.lower(); events = [e for e in events if any(tl in t.lower() for t in e.get("tags", []))]
    print(f"\n📖 {len(events)} events\n")
    for e in events: print(f"  [{e['id']}] B{e['book']} Ch{e.get('chapter','?')}: {e['title']}")

def cmd_search(query):
    ql = query.lower()
    results = [e for e in CANON_EVENTS if ql in (e.get("title","") + e.get("description","") + " ".join(e.get("characters",[])) + " ".join(e.get("tags",[]))).lower()]
    print(f"\n🔍 '{query}': {len(results)} results\n")
    for e in results: print(f"  [{e['id']}] B{e['book']}: {e['title']}\n    {e['description'][:120]}...\n")

def cmd_list_arcs(character=None):
    if character:
        cl = character.lower()
        for name, arcs in CHARACTER_ARCS.items():
            if cl in name.lower():
                print(f"\n👤 {name}\n")
                for b in sorted(arcs.keys()): print(f"  Book {b}: {arcs[b]}\n")
                return
        print(f"  ✗ Not found: {character}")
    else:
        print(f"\n👤 {len(CHARACTER_ARCS)} character arcs:\n")
        for name in sorted(CHARACTER_ARCS.keys()): print(f"  {name}")

def cmd_list_foreshadowing():
    print(f"\n🔮 {len(FORESHADOWING)} foreshadowing setups:\n")
    for f in FORESHADOWING: print(f"  B{f['setup_book']} → B{f['payoff_book']}: {f['setup_event'][:60]}... → {f['payoff_event'][:60]}...\n")

def main():
    parser = argparse.ArgumentParser(description="Canon References Agent", formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("build")
    sub.add_parser("update-outline")
    p = sub.add_parser("remind"); p.add_argument("part_id")
    p = sub.add_parser("list-events"); p.add_argument("--book", type=int); p.add_argument("--character"); p.add_argument("--tag")
    p = sub.add_parser("search"); p.add_argument("query")
    p = sub.add_parser("list-arcs"); p.add_argument("--character")
    sub.add_parser("list-foreshadowing")
    args = parser.parse_args()
    if not args.command: parser.print_help(); return
    cmds = {"build": cmd_build, "remind": lambda: cmd_remind(args.part_id), "list-events": lambda: cmd_list_events(args.book, args.character, args.tag),
            "search": lambda: cmd_search(args.query), "list-arcs": lambda: cmd_list_arcs(args.character), "list-foreshadowing": cmd_list_foreshadowing}
    if args.command in cmds: cmds[args.command]()
    elif args.command == "update-outline": print("  ℹ update-outline requires story_outline_data.json")

CANON_CSS = """
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth;scroll-padding-top:80px}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Noto Sans',sans-serif;background:#0a0612;color:#e8e3d3;line-height:1.7}
.top-nav{position:sticky;top:0;z-index:100;background:rgba(10,6,18,.92);backdrop-filter:blur(20px);border-bottom:1px solid rgba(180,140,80,.25);padding:12px 0}
.nav-inner{max-width:1400px;margin:0 auto;padding:0 24px;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
.nav-brand{font-weight:800;color:#d4a857;text-decoration:none;font-size:16px}
.nav-links{display:flex;gap:12px;flex:1;flex-wrap:wrap}
.nav-links a{color:#b8ad95;text-decoration:none;font-size:12px;padding:2px 0;border-bottom:2px solid transparent}
.nav-links a:hover{color:#e8d5a0;border-bottom-color:#d4a857}
.nav-search input{background:rgba(255,255,255,.06);border:1px solid rgba(212,168,87,.3);color:#e8e3d3;padding:6px 30px 6px 12px;border-radius:999px;font-size:13px;width:200px}
.nav-search input:focus{outline:none;border-color:#d4a857;width:260px}
.search-clear{position:absolute;right:8px;background:none;border:none;color:#8a7e6a;cursor:pointer;font-size:18px;display:none}
.main{max-width:1400px;margin:0 auto;padding:48px 24px}
.page-header{text-align:center;margin-bottom:48px;padding:32px;background:linear-gradient(180deg,rgba(20,12,35,.6),rgba(10,6,18,.4));border:1px solid rgba(212,168,87,.25);border-radius:16px}
.page-header h1{font-size:32px;background:linear-gradient(135deg,#f4d77a,#d4a857);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:8px}
.page-header p{color:#b8ad95;font-size:13px}
.section{margin-bottom:64px}
.section h2{font-size:24px;font-weight:800;background:linear-gradient(135deg,#f4d77a,#d4a857);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:20px;padding-bottom:10px;border-bottom:1px solid rgba(212,168,87,.25)}
.section h3{color:#d4a857;font-size:18px;margin:20px 0 12px}
.card{background:rgba(255,255,255,.025);border:1px solid rgba(212,168,87,.15);border-radius:10px;padding:16px;margin-bottom:12px}
.card h3{color:#f4d77a;font-size:15px;margin-bottom:6px}
.card h4{color:#f4d77a;font-size:14px;margin-bottom:4px}
.card p{font-size:13px;color:#c8bda5;margin-bottom:4px}
.card .muted{color:#6a604f;font-size:11px}
.grid-2{display:grid;grid-template-columns:repeat(auto-fill,minmax(400px,1fr));gap:12px}
.grid-3{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px}
.event-high{border-left:3px solid #e8342a}
.event-medium{border-left:3px solid #d4a857}
.event-low{border-left:3px solid #6a604f}
.event-header{display:flex;justify-content:space-between;margin-bottom:4px}
.badge{font-size:9px;padding:2px 6px;border-radius:3px;background:rgba(212,168,87,.2);color:#d4a857}
.badge.green{background:rgba(74,157,90,.2);color:#4a9d5a}
.arc-year{margin-bottom:10px;padding-left:12px;border-left:2px solid rgba(212,168,87,.2)}
.arc-year h5{color:#d4a857;font-size:13px;margin-bottom:3px}
.fs-card{display:grid;grid-template-columns:1fr auto 1fr;gap:10px;align-items:center}
.fs-setup{background:rgba(244,167,66,.08);padding:8px;border-radius:6px}
.fs-payoff{background:rgba(74,157,90,.08);padding:8px;border-radius:6px}
.fs-arrow{font-size:24px;color:#d4a857;text-align:center}
.search-hidden{display:none!important}
.search-highlight{background:rgba(244,215,122,.3);color:#f4d77a;padding:0 2px;border-radius:2px}
@media(max-width:768px){.grid-2,.grid-3{grid-template-columns:1fr}.fs-card{grid-template-columns:1fr}.fs-arrow{transform:rotate(90deg)}}
"""

CANON_JS = """
function performSearch(q){var c=document.getElementById('search-clear');q=(q||'').trim();document.querySelectorAll('.search-highlight').forEach(function(e){var p=e.parentNode;p.replaceChild(document.createTextNode(e.textContent),e);p.normalize()});if(!q){document.querySelectorAll('.search-hidden').forEach(function(e){e.classList.remove('search-hidden')});c.style.display='none';return}c.style.display='block';var ql=q.toLowerCase();document.querySelectorAll('.card,.section h3,.page-header p').forEach(function(e){if((e.textContent||'').toLowerCase().indexOf(ql)>=0){e.classList.remove('search-hidden')}else{e.classList.add('search-hidden')}})}
function clearSearch(){var b=document.getElementById('search-box');b.value='';performSearch('');b.focus()}
document.addEventListener('keydown',function(e){if(e.key==='/'&&document.activeElement.tagName!=='INPUT'){e.preventDefault();document.getElementById('search-box').focus()}if(e.key==='Escape'&&document.activeElement.id==='search-box'){clearSearch();document.getElementById('search-box').blur()}});
"""

if __name__ == "__main__": main()
