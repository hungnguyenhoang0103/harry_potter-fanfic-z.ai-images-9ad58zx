"""
shared.py — Shared utilities for all agents.

Provides:
- load_config(): Load project.json
- output(): Compact JSON output
- file_lock(): File locking (prevents conflicts)
- load_character(): Lazy load single character
- load_all_characters(): Load all characters
- save_character(): Save character with lock
- detect_format(): Detect image format from bytes
- github helpers: load_github_config, load_github_token, upload_to_github

Usage (from any agent):
  import sys; sys.path.insert(0, "/home/z/my-project/scripts/agents")
  from shared import *
"""
import json
import os
import fcntl
import base64
import requests
from contextlib import contextmanager
from pathlib import Path

PROJECT_ROOT = "/home/z/my-project"
CONFIG_PATH = f"{PROJECT_ROOT}/project.json"


# ============================================================================
# CONFIG
# ============================================================================
def load_config():
    """Load project.json config."""
    with open(CONFIG_PATH) as f:
        return json.load(f)


def resolve_path(config, key):
    """Resolve a path from config (relative to PROJECT_ROOT)."""
    val = config.get(key, "")
    if os.path.isabs(val):
        return val
    return os.path.join(PROJECT_ROOT, val)


# ============================================================================
# OUTPUT
# ============================================================================
def output(data, verbose=False):
    """Compact JSON output by default. Verbose = pretty-print."""
    if verbose:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print(json.dumps(data, ensure_ascii=False))


# ============================================================================
# FILE LOCKING
# ============================================================================
LOCK_DIR = f"{PROJECT_ROOT}/scripts/data/.locks"
os.makedirs(LOCK_DIR, exist_ok=True)


@contextmanager
def file_lock(lock_name):
    """Context manager for file locking. Prevents cross-session conflicts."""
    lock_path = os.path.join(LOCK_DIR, f"{lock_name}.lock")
    lock_file = open(lock_path, 'w')
    try:
        fcntl.flock(lock_file, fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(lock_file, fcntl.LOCK_UN)
        lock_file.close()


# ============================================================================
# CHARACTER DATA (lazy loading from per-character JSON files)
# ============================================================================
def load_character(config, char_id):
    """Load single character from JSON file (lazy loading)."""
    chars_dir = resolve_path(config, "characters_dir")
    path = os.path.join(chars_dir, f"{char_id}.json")
    if not os.path.exists(path):
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except:
        return None


def load_all_characters(config):
    """Load all characters."""
    chars_dir = resolve_path(config, "characters_dir")
    chars = {}
    if not os.path.exists(chars_dir):
        return chars
    for fname in os.listdir(chars_dir):
        if fname.endswith('.json') and not fname.startswith('_'):
            try:
                with open(os.path.join(chars_dir, fname)) as f:
                    d = json.load(f)
                    chars[d["id"]] = d
            except:
                pass
    return chars


def save_character(config, char_data):
    """Save single character with file lock."""
    chars_dir = resolve_path(config, "characters_dir")
    os.makedirs(chars_dir, exist_ok=True)
    char_id = char_data["id"]
    path = os.path.join(chars_dir, f"{char_id}.json")
    with file_lock(f"char_{char_id}"):
        with open(path, 'w') as f:
            json.dump(char_data, f, ensure_ascii=False, indent=2)


# ============================================================================
# IMAGE FORMAT DETECTION
# ============================================================================
def detect_format(content_bytes):
    """Detect image format from magic bytes."""
    h = content_bytes[:16]
    if h[:4] == b'RIFF' and h[8:12] == b'WEBP': return 'webp'
    if h[:8] == b'\x89PNG\r\n\x1a\n': return 'png'
    if h[:3] == b'\xff\xd8\xff': return 'jpg'
    if h[:6] in (b'GIF87a', b'GIF89a'): return 'gif'
    if h[:2] == b'BM': return 'bmp'
    return 'jpg'


# ============================================================================
# GITHUB HELPERS
# ============================================================================
def load_github_config(config):
    """Load GitHub config."""
    path = resolve_path(config, "github_config")
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {}


def load_github_token(config):
    """Load GitHub PAT."""
    path = resolve_path(config, "github_token")
    if os.path.exists(path):
        return open(path).read().strip()
    return None


def upload_to_github(config, content_bytes, char_id, image_key, position):
    """Upload image to GitHub, return raw URL."""
    gh_config = load_github_config(config)
    token = load_github_token(config)
    if not token:
        return None, "No GitHub PAT found"
    
    ext = detect_format(content_bytes)
    filename = f"{image_key}_{position:02d}.{ext}"
    path = f"{gh_config['base_path']}/{char_id}/{filename}"
    
    content_b64 = base64.b64encode(content_bytes).decode("ascii")
    url = f"https://api.github.com/repos/{gh_config['username']}/{gh_config['repo']}/contents/{path}"
    headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}
    data = {"message": f"Upload {filename}", "content": content_b64, "branch": gh_config["branch"]}
    
    try:
        r = requests.put(url, headers=headers, json=data, timeout=60)
        if r.status_code not in (200, 201):
            return None, f"Upload failed: HTTP {r.status_code}"
    except Exception as e:
        return None, f"Upload error: {e}"
    
    raw_url = f"https://raw.githubusercontent.com/{gh_config['username']}/{gh_config['repo']}/{gh_config['branch']}/{path}"
    return raw_url, None


# ============================================================================
# BUILD HELPERS
# ============================================================================
def rebuild_html(config, target="all"):
    """Rebuild HTML files."""
    results = {}
    root = resolve_path(config, "root_dir")
    
    if target in ("all", "bible"):
        build_script = resolve_path(config, "build_html")
        ret = os.system(f"cd {root} && python3 {build_script} > /dev/null 2>&1")
        results["bible"] = "ok" if ret == 0 else "error"
    
    if target in ("all", "outline"):
        build_script = resolve_path(config, "build_outline_html")
        ret = os.system(f"cd {root} && python3 {build_script} > /dev/null 2>&1")
        results["outline"] = "ok" if ret == 0 else "error"
    
    return results
