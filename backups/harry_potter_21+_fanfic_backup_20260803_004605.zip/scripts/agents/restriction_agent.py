#!/usr/bin/env python3
"""
restriction_agent.py — Restriction management & checking (generic, config-driven).

3 scopes:
  global     — All stories (restrictions/global.json)
  style:X    — Style-specific (restrictions/style_X.json)
  project    — Project-specific (restrictions/project_<name>.json)

4 types:
  banned_words      — Words/phrases banned (exact + fuzzy match)
  banned_sentences  — Sentences banned (exact + partial match)
  context_limits    — Frequency limits for contexts/scenarios
  soft_guidance     — Soft rules (warnings, not errors)

Commands:
  check <text>                          Check text string against restrictions
  check-file <path>                     Check file against restrictions
  add word <value> [--scope S] [--reason R] [--similar S1,S2]
  add sentence <value> [--scope S] [--reason R]
  add context <value> --max N --per part|arc [--scope S] [--reason R]
  add guidance <value> [--scope S] [--priority low|medium|high]
  list [--scope S] [--type T]           List restrictions
  remove <id> [--scope S]               Remove restriction by ID
  stats                                 Show restriction statistics

Usage:
  python3 scripts/agents/restriction_agent.py check-file /tmp/part1.txt
  python3 scripts/agents/restriction_agent.py add word "nghi lễ thanh tẩy" --scope global --reason "Cấm cụm từ"
  python3 scripts/agents/restriction_agent.py list --scope global
"""
import argparse
import json
import os
import re
import sys
import uuid
from collections import Counter

sys.path.insert(0, os.path.dirname(__file__))
from shared import *

RESTRICTIONS_DIR = f"{PROJECT_ROOT}/restrictions"


# ============================================================================
# LOAD / SAVE RESTRICTIONS
# ============================================================================
def get_restriction_path(scope, config):
    """Get file path for a scope."""
    if scope == "global":
        return os.path.join(RESTRICTIONS_DIR, "global.json")
    elif scope.startswith("style:"):
        style_name = scope.split(":", 1)[1]
        return os.path.join(RESTRICTIONS_DIR, f"style_{style_name}.json")
    elif scope == "project":
        project_name = config.get("name", "project").replace(" ", "_").lower()
        return os.path.join(RESTRICTIONS_DIR, f"project_{project_name}.json")
    else:
        return os.path.join(RESTRICTIONS_DIR, f"{scope}.json")


def load_restrictions(scope, config):
    """Load restrictions for a scope."""
    path = get_restriction_path(scope, config)
    if not os.path.exists(path):
        return {"banned_words": [], "banned_sentences": [], "context_limits": [], "soft_guidance": []}
    try:
        with open(path) as f:
            return json.load(f)
    except:
        return {"banned_words": [], "banned_sentences": [], "context_limits": [], "soft_guidance": []}


def load_all_restrictions(config, active_scopes=None):
    """Load restrictions from multiple scopes, merge."""
    if active_scopes is None:
        active_scopes = ["global"]
        # Add project scope
        project_name = config.get("name", "project").replace(" ", "_").lower()
        project_path = os.path.join(RESTRICTIONS_DIR, f"project_{project_name}.json")
        if os.path.exists(project_path):
            active_scopes.append("project")
    
    merged = {"banned_words": [], "banned_sentences": [], "context_limits": [], "soft_guidance": []}
    for scope in active_scopes:
        r = load_restrictions(scope, config)
        for key in merged:
            for item in r.get(key, []):
                item["_scope"] = scope
                merged[key].append(item)
    return merged


def save_restrictions(scope, config, data):
    """Save restrictions for a scope."""
    path = get_restriction_path(scope, config)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # Remove _scope field before saving
    clean = {"banned_words": [], "banned_sentences": [], "context_limits": [], "soft_guidance": []}
    for key in clean:
        for item in data.get(key, []):
            item_copy = {k: v for k, v in item.items() if k != "_scope"}
            clean[key].append(item_copy)
    with file_lock(f"restrictions_{scope}"):
        with open(path, 'w') as f:
            json.dump(clean, f, ensure_ascii=False, indent=2)


# ============================================================================
# FUZZY MATCHING (for similar words)
# ============================================================================
def levenshtein(s1, s2):
    """Simple Levenshtein distance."""
    if len(s1) < len(s2):
        return levenshtein(s2, s1)
    if len(s2) == 0:
        return len(s1)
    prev = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        curr = [i + 1]
        for j, c2 in enumerate(s2):
            ins = prev[j + 1] + 1
            dele = curr[j] + 1
            sub = prev[j] + (c1 != c2)
            curr.append(min(ins, dele, sub))
        prev = curr
    return prev[-1]


def is_similar(text, word, threshold=0.8):
    """Check if text contains word or similar variant."""
    text_lower = text.lower()
    word_lower = word.lower()
    
    # Exact match
    if word_lower in text_lower:
        return True, "exact"
    
    # Check similar variants
    # Split text into words and check each
    words_in_text = re.split(r'\s+', text_lower)
    word_parts = word_lower.split()
    
    if len(word_parts) == 1:
        # Single word — check each word in text
        for w in words_in_text:
            w = re.sub(r'[^\w]', '', w)
            if not w:
                continue
            distance = levenshtein(w, word_lower)
            max_len = max(len(w), len(word_lower))
            similarity = 1 - distance / max_len if max_len > 0 else 0
            if similarity >= threshold:
                return True, f"similar ({similarity:.0%}): '{w}' ≈ '{word_lower}'"
    else:
        # Multi-word phrase — check sliding window
        for i in range(len(words_in_text) - len(word_parts) + 1):
            window = " ".join(words_in_text[i:i + len(word_parts)])
            window = re.sub(r'[^\w\s]', '', window)
            phrase_clean = re.sub(r'[^\w\s]', '', word_lower)
            distance = levenshtein(window, phrase_clean)
            max_len = max(len(window), len(phrase_clean))
            similarity = 1 - distance / max_len if max_len > 0 else 0
            if similarity >= threshold:
                return True, f"similar ({similarity:.0%}): '{window}' ≈ '{word_lower}'"
    
    return False, None


# ============================================================================
# CHECK TEXT
# ============================================================================
def check_text(text, restrictions):
    """Check text against all restrictions. Returns violations + warnings."""
    violations = []
    warnings = []
    
    text_lower = text.lower()
    
    # Check banned words
    for item in restrictions.get("banned_words", []):
        word = item.get("word", "")
        if not word:
            continue
        
        found, match_type = is_similar(text, word)
        if found:
            # Count occurrences
            count = text_lower.count(word.lower())
            violations.append({
                "type": "banned_word",
                "id": item.get("id"),
                "word": word,
                "match": match_type,
                "count": count if count > 0 else 1,
                "reason": item.get("reason", ""),
                "scope": item.get("_scope", "global"),
                "similar": item.get("similar", []),
            })
    
    # Check banned sentences
    for item in restrictions.get("banned_sentences", []):
        sentence = item.get("sentence", "")
        if not sentence:
            continue
        
        # Check if sentence (or key part) appears in text
        sentence_lower = sentence.lower()
        # For long sentences, check first 10 words as partial match
        words = sentence_lower.split()
        if len(words) > 5:
            partial = " ".join(words[:5])
            if partial in text_lower:
                violations.append({
                    "type": "banned_sentence",
                    "id": item.get("id"),
                    "sentence": sentence,
                    "match": "partial",
                    "reason": item.get("reason", ""),
                    "scope": item.get("_scope", "global"),
                })
                continue
        
        if sentence_lower in text_lower:
            violations.append({
                "type": "banned_sentence",
                "id": item.get("id"),
                "sentence": sentence,
                "match": "exact",
                "reason": item.get("reason", ""),
                "scope": item.get("_scope", "global"),
            })
    
    # Check context limits (just count, don't enforce — enforcement needs history)
    for item in restrictions.get("context_limits", []):
        context = item.get("context", "")
        if not context:
            continue
        
        context_lower = context.lower()
        count = text_lower.count(context_lower)
        if count > 0:
            max_val = item.get("max_per_part", item.get("max_per_arc", item.get("max_percentage", 100)))
            if isinstance(max_val, int) and max_val <= 10:
                if count > max_val:
                    violations.append({
                        "type": "context_limit_exceeded",
                        "id": item.get("id"),
                        "context": context,
                        "count": count,
                        "max": max_val,
                        "per": "part" if "max_per_part" in item else "arc",
                        "reason": item.get("reason", ""),
                        "scope": item.get("_scope", "global"),
                    })
                elif count >= max_val * 0.8:
                    warnings.append({
                        "type": "context_limit_warning",
                        "id": item.get("id"),
                        "context": context,
                        "count": count,
                        "max": max_val,
                        "message": f"'{context}' approaching limit ({count}/{max_val})",
                    })
    
    # Soft guidance (always warnings, never violations)
    for item in restrictions.get("soft_guidance", []):
        guidance = item.get("guidance", "")
        if guidance:
            # Check if guidance keywords appear in text (very rough)
            keywords = [w for w in guidance.lower().split() if len(w) > 3]
            matched = [kw for kw in keywords if kw in text_lower]
            if len(matched) >= 2:
                warnings.append({
                    "type": "soft_guidance",
                    "id": item.get("id"),
                    "guidance": guidance,
                    "priority": item.get("priority", "medium"),
                    "matched_keywords": matched,
                    "scope": item.get("_scope", "global"),
                })
    
    return {
        "violations": violations,
        "warnings": warnings,
        "violation_count": len(violations),
        "warning_count": len(warnings),
        "clean": len(violations) == 0,
    }


# ============================================================================
# COMMANDS
# ============================================================================
def cmd_check(config, args):
    """Check text string."""
    restrictions = load_all_restrictions(config)
    result = check_text(args.text, restrictions)
    output(result, args.verbose)


def cmd_check_file(config, args):
    """Check file content."""
    if not os.path.exists(args.path):
        output({"status": "error", "message": f"File not found: {args.path}"})
        return
    
    with open(args.path, encoding="utf-8") as f:
        text = f.read()
    
    restrictions = load_all_restrictions(config)
    result = check_text(text, restrictions)
    result["file"] = args.path
    result["text_length"] = len(text)
    output(result, args.verbose)


def cmd_add(config, args):
    """Add restriction."""
    scope = args.scope or "global"
    restrictions = load_restrictions(scope, config)
    
    if args.type == "word":
        item = {
            "id": f"bw_{uuid.uuid4().hex[:6]}",
            "word": args.value,
            "reason": args.reason or "",
        }
        if args.similar:
            item["similar"] = [s.strip() for s in args.similar.split(",")]
        restrictions["banned_words"].append(item)
    
    elif args.type == "sentence":
        item = {
            "id": f"bs_{uuid.uuid4().hex[:6]}",
            "sentence": args.value,
            "reason": args.reason or "",
        }
        restrictions["banned_sentences"].append(item)
    
    elif args.type == "context":
        item = {
            "id": f"cl_{uuid.uuid4().hex[:6]}",
            "context": args.value,
            "reason": args.reason or "",
        }
        if args.per == "part":
            item["max_per_part"] = args.max
        elif args.per == "arc":
            item["max_per_arc"] = args.max
        elif args.per == "percentage":
            item["max_percentage"] = args.max
        restrictions["context_limits"].append(item)
    
    elif args.type == "guidance":
        item = {
            "id": f"sg_{uuid.uuid4().hex[:6]}",
            "guidance": args.value,
            "priority": args.priority or "medium",
        }
        restrictions["soft_guidance"].append(item)
    
    save_restrictions(scope, config, restrictions)
    output({"status": "ok", "added": item, "scope": scope}, args.verbose)


def cmd_list(config, args):
    """List restrictions."""
    if args.scope:
        scopes = [args.scope]
    else:
        # List all
        scopes = []
        for fname in os.listdir(RESTRICTIONS_DIR) if os.path.exists(RESTRICTIONS_DIR) else []:
            if fname.endswith(".json"):
                if fname == "global.json":
                    scopes.append("global")
                elif fname.startswith("style_"):
                    scopes.append(f"style:{fname[6:-5]}")
                elif fname.startswith("project_"):
                    scopes.append("project")
    
    all_items = []
    for scope in scopes:
        r = load_restrictions(scope, config)
        for rtype in ["banned_words", "banned_sentences", "context_limits", "soft_guidance"]:
            if args.type and args.type != rtype:
                continue
            for item in r.get(rtype, []):
                item["_scope"] = scope
                item["_type"] = rtype
                all_items.append(item)
    
    output({"restrictions": all_items, "count": len(all_items)}, args.verbose)


def cmd_remove(config, args):
    """Remove restriction by ID."""
    scope = args.scope or "global"
    restrictions = load_restrictions(scope, config)
    
    removed = False
    for rtype in ["banned_words", "banned_sentences", "context_limits", "soft_guidance"]:
        before = len(restrictions[rtype])
        restrictions[rtype] = [item for item in restrictions[rtype] if item.get("id") != args.id]
        after = len(restrictions[rtype])
        if after < before:
            removed = True
    
    if removed:
        save_restrictions(scope, config, restrictions)
        output({"status": "ok", "removed": args.id, "scope": scope}, args.verbose)
    else:
        output({"status": "error", "message": f"ID '{args.id}' not found in scope '{scope}'"}, args.verbose)


def cmd_stats(config, args):
    """Show restriction statistics."""
    stats = {}
    if os.path.exists(RESTRICTIONS_DIR):
        for fname in os.listdir(RESTRICTIONS_DIR):
            if fname.endswith(".json"):
                scope = fname[:-5]
                r = load_restrictions(scope, config)
                stats[scope] = {
                    "banned_words": len(r.get("banned_words", [])),
                    "banned_sentences": len(r.get("banned_sentences", [])),
                    "context_limits": len(r.get("context_limits", [])),
                    "soft_guidance": len(r.get("soft_guidance", [])),
                    "total": sum(len(r.get(k, [])) for k in ["banned_words", "banned_sentences", "context_limits", "soft_guidance"]),
                }
    output(stats, args.verbose)


# ============================================================================
# MAIN
# ============================================================================
def main():
    parser = argparse.ArgumentParser(
        description="Restriction Agent — Banned words/sentences/contexts checker",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command")
    
    # check
    p_check = sub.add_parser("check", help="Check text string")
    p_check.add_argument("text", help="Text to check")
    
    # check-file
    p_cf = sub.add_parser("check-file", help="Check file content")
    p_cf.add_argument("path", help="File path to check")
    
    # add
    p_add = sub.add_parser("add", help="Add restriction")
    p_add.add_argument("type", choices=["word", "sentence", "context", "guidance"])
    p_add.add_argument("value", help="Word/sentence/context/guidance text")
    p_add.add_argument("--scope", default="global", help="global | style:X | project")
    p_add.add_argument("--reason", help="Reason for restriction")
    p_add.add_argument("--similar", help="Comma-separated similar variants (for words)")
    p_add.add_argument("--max", type=int, help="Max count (for context)")
    p_add.add_argument("--per", choices=["part", "arc", "percentage"], default="part", help="Per part/arc/percentage")
    p_add.add_argument("--priority", choices=["low", "medium", "high"], help="Priority (for guidance)")
    
    # list
    p_list = sub.add_parser("list", help="List restrictions")
    p_list.add_argument("--scope", help="Filter by scope")
    p_list.add_argument("--type", choices=["banned_words", "banned_sentences", "context_limits", "soft_guidance"])
    
    # remove
    p_remove = sub.add_parser("remove", help="Remove restriction by ID")
    p_remove.add_argument("id", help="Restriction ID")
    p_remove.add_argument("--scope", default="global")
    
    # stats
    sub.add_parser("stats", help="Show restriction statistics")
    
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()
    
    config = load_config()
    
    if args.command == "check": cmd_check(config, args)
    elif args.command == "check-file": cmd_check_file(config, args)
    elif args.command == "add": cmd_add(config, args)
    elif args.command == "list": cmd_list(config, args)
    elif args.command == "remove": cmd_remove(config, args)
    elif args.command == "stats": cmd_stats(config, args)
    else: parser.print_help()


if __name__ == "__main__":
    main()
