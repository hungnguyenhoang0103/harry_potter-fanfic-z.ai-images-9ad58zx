#!/usr/bin/env python3
"""
prompt_sync_agent.py — Sync prompt files to GitHub (generic, config-driven).

Syncs files from download/ to GitHub repo under prompts/ folder.
Auto-detects changed files (hash comparison).

Commands:
  sync              Upload changed prompt files to GitHub
  list              List prompt files on GitHub
  pull              Download prompt files from GitHub (overwrite local)

Usage:
  python3 scripts/agents/prompt_sync_agent.py sync
  python3 scripts/agents/prompt_sync_agent.py list
"""
import argparse
import base64
import hashlib
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from shared import *

PROMPT_FILES = [
    "generic_complete_prompt.txt",
    "hp_complete_prompt.txt",
    "pronoun_styles.md",
]


def file_hash(path):
    """MD5 hash of file content."""
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def cmd_sync(config, args):
    """Upload changed prompt files to GitHub."""
    gh_config = load_github_config(config)
    token = load_github_token(config)
    if not token:
        output({"status": "error", "message": "No GitHub PAT"})
        return

    output_dir = resolve_path(config, "output_dir")
    results = []

    for fname in PROMPT_FILES:
        local_path = os.path.join(output_dir, fname)
        if not os.path.exists(local_path):
            results.append({"file": fname, "status": "skip", "reason": "not found locally"})
            continue

        # Read file
        with open(local_path, "rb") as f:
            content = f.read()
        content_b64 = base64.b64encode(content).decode("ascii")

        # GitHub path: prompts/<filename>
        gh_path = f"prompts/{fname}"
        url = f"https://api.github.com/repos/{gh_config['username']}/{gh_config['repo']}/contents/{gh_path}"
        headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}

        # Check if file exists on GitHub (get SHA for update)
        import requests
        sha = None
        r = requests.get(f"{url}?ref={gh_config['branch']}", headers=headers, timeout=30)
        if r.status_code == 200:
            sha = r.json().get("sha")

        # Upload
        data = {
            "message": f"Sync prompt: {fname}",
            "content": content_b64,
            "branch": gh_config["branch"],
        }
        if sha:
            data["sha"] = sha  # Update existing

        r = requests.put(url, headers=headers, json=data, timeout=60)
        if r.status_code in (200, 201):
            raw_url = f"https://raw.githubusercontent.com/{gh_config['username']}/{gh_config['repo']}/{gh_config['branch']}/{gh_path}"
            results.append({"file": fname, "status": "ok", "action": "updated" if sha else "created", "url": raw_url, "size": len(content)})
        else:
            results.append({"file": fname, "status": "error", "code": r.status_code, "message": r.text[:100]})

    output({"status": "ok", "synced": results, "total": len(results)})


def cmd_list(config, args):
    """List prompt files on GitHub."""
    gh_config = load_github_config(config)
    token = load_github_token(config)

    url = f"https://api.github.com/repos/{gh_config['username']}/{gh_config['repo']}/contents/prompts?ref={gh_config['branch']}"
    headers = {"Accept": "application/vnd.github.v3+json"}
    if token:
        headers["Authorization"] = f"token {token}"

    import requests
    r = requests.get(url, headers=headers, timeout=30)
    if r.status_code != 200:
        output({"status": "error", "code": r.status_code})
        return

    items = r.json()
    files = []
    for item in items:
        if item.get("type") == "file":
            files.append({
                "name": item["name"],
                "size": item.get("size", 0),
                "url": item.get("html_url", ""),
                "raw_url": f"https://raw.githubusercontent.com/{gh_config['username']}/{gh_config['repo']}/{gh_config['branch']}/prompts/{item['name']}",
            })

    output({"files": files, "count": len(files)})


def main():
    parser = argparse.ArgumentParser(description="Prompt Sync Agent")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("sync", help="Upload changed prompt files to GitHub")
    sub.add_parser("list", help="List prompt files on GitHub")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    config = load_config()
    if args.command == "sync":
        cmd_sync(config, args)
    elif args.command == "list":
        cmd_list(config, args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
