#!/usr/bin/env python3
"""
canon_agent.py — Canon reference agent (generic, config-driven).

Commands:
  remind <part_id>          Get canon reminder (previous/current/next events)
  search <query>            Search canon events
  list-events [--book N]    List events, optionally filtered by book
  build                     Build canon reference HTML

Usage:
  python3 scripts/agents/canon_agent.py remind arc1_ch1_p1
  python3 scripts/agents/canon_agent.py search "Quidditch"
  python3 scripts/agents/canon_agent.py list-events --book 1
"""
import argparse, sys, os, re
sys.path.insert(0, os.path.dirname(__file__))
from shared import *

def load_canon(config):
    """Dynamically import canon_data module."""
    canon_path = resolve_path(config, "canon_data")
    canon_dir = os.path.dirname(canon_path)
    if canon_dir not in sys.path:
        sys.path.insert(0, canon_dir)
    import canon_data
    return canon_data

def cmd_remind(config, args):
    canon = load_canon(config)
    m = re.match(r'arc(\d+)_ch(\d+)_p(\d+)', args.part_id)
    if not m:
        output({"status": "error", "message": f"Invalid part_id: {args.part_id}"})
        return
    arc_num, ch_num = int(m.group(1)), int(m.group(2))
    book_num = arc_num
    
    events = canon.CANON_EVENTS
    prev = [e for e in events if e["book"] == book_num and e.get("chapter", 0) < ch_num]
    curr = [e for e in events if e["book"] == book_num and abs(e.get("chapter", 0) - ch_num) <= 1]
    nxt = [e for e in events if e["book"] == book_num and e.get("chapter", 0) > ch_num]
    
    output({
        "part_id": args.part_id,
        "book": book_num,
        "book_title": canon.BOOKS.get(book_num, {}).get("title", "?"),
        "previous": prev[-1] if prev else None,
        "current": curr[:3],
        "next": nxt[0] if nxt else None,
        "upcoming": [e["title"] for e in nxt[1:4]],
    })

def cmd_search(config, args):
    canon = load_canon(config)
    ql = args.query.lower()
    results = []
    for e in canon.CANON_EVENTS:
        searchable = " ".join([e.get("title",""), e.get("description",""), " ".join(e.get("characters",[])), " ".join(e.get("tags",[]))]).lower()
        if ql in searchable:
            results.append({"id": e["id"], "book": e["book"], "title": e["title"], "description": e["description"][:120]})
    output({"query": args.query, "results": results, "count": len(results)})

def cmd_list_events(config, args):
    canon = load_canon(config)
    events = canon.CANON_EVENTS
    if args.book:
        events = [e for e in events if e["book"] == args.book]
    output({"events": [{"id": e["id"], "book": e["book"], "chapter": e.get("chapter","?"), "title": e["title"]} for e in events], "count": len(events)})

def cmd_build(config, args):
    # Use existing canon_references_agent.py if available
    agent_path = os.path.join(os.path.dirname(__file__), "canon_references_agent.py")
    if os.path.exists(agent_path):
        root = resolve_path(config, "root_dir")
        ret = os.system(f"cd {root} && python3 {agent_path} build > /dev/null 2>&1")
        output({"status": "ok" if ret == 0 else "error"})
    else:
        output({"status": "error", "message": "canon_references_agent.py not found"})

def main():
    parser = argparse.ArgumentParser(description="Canon Agent")
    sub = parser.add_subparsers(dest="command")
    p_r = sub.add_parser("remind"); p_r.add_argument("part_id")
    p_s = sub.add_parser("search"); p_s.add_argument("query")
    p_le = sub.add_parser("list-events"); p_le.add_argument("--book", type=int)
    sub.add_parser("build")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()
    
    config = load_config()
    if args.command == "remind": cmd_remind(config, args)
    elif args.command == "search": cmd_search(config, args)
    elif args.command == "list-events": cmd_list_events(config, args)
    elif args.command == "build": cmd_build(config, args)
    else: parser.print_help()

if __name__ == "__main__": main()
