#!/usr/bin/env python3
"""
image_agent.py — Image management agent (generic, config-driven).

Commands:
  add <char_id> <url_or_file>     Add image for character
  list <char_id>                  List images for character
  check                           Check all URLs for broken ones
  sync <char_id?>                 Sync from GitHub

Usage:
  python3 scripts/agents/image_agent.py add hermione_granger https://i.pinimg.com/...
  python3 scripts/agents/image_agent.py list hermione_granger
  python3 scripts/agents/image_agent.py check
  python3 scripts/agents/image_agent.py sync hermione_granger
"""
import argparse, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from shared import *

def cmd_add(config, args):
    char = load_character(config, args.char_id)
    if not char:
        output({"status": "error", "message": f"Character '{args.char_id}' not found"})
        return
    
    import requests
    source = args.source
    
    if source.startswith("http"):
        try:
            r = requests.get(source, timeout=60, headers={"User-Agent": "Mozilla/5.0"})
            r.raise_for_status()
            content = r.content
        except Exception as e:
            output({"status": "error", "message": f"Download failed: {e}"})
            return
    elif os.path.exists(source):
        with open(source, 'rb') as f:
            content = f.read()
    else:
        output({"status": "error", "message": f"Source not found: {source}"})
        return
    
    image_key = char.get("image_key", args.char_id)
    next_pos = len(char.get("image_urls", [])) + 1
    
    raw_url, err = upload_to_github(config, content, args.char_id, image_key, next_pos)
    if err:
        output({"status": "error", "message": err})
        return
    
    if "image_urls" not in char:
        char["image_urls"] = []
    char["image_urls"].append(raw_url)
    save_character(config, char)
    
    output({"status": "ok", "char_id": args.char_id, "position": next_pos, "url": raw_url, "total": len(char["image_urls"])})

def cmd_list(config, args):
    char = load_character(config, args.char_id)
    if not char:
        output({"status": "error", "message": f"Character '{args.char_id}' not found"})
        return
    urls = char.get("image_urls", [])
    output({"char_id": args.char_id, "name": char["name"], "count": len(urls), "urls": urls})

def cmd_check(config, args):
    import requests
    chars = load_all_characters(config)
    broken = []
    total = ok = 0
    for cid, char in chars.items():
        for i, url in enumerate(char.get("image_urls", []), 1):
            if url.startswith("data:"): continue
            total += 1
            try:
                resp = requests.head(url, timeout=10, allow_redirects=True)
                if resp.status_code == 200: ok += 1
                else: broken.append({"char_id": cid, "name": char["name"], "pos": i, "status": resp.status_code, "url": url[-60:]})
            except Exception as e:
                broken.append({"char_id": cid, "name": char["name"], "pos": i, "error": str(e)[:50], "url": url[-60:]})
    output({"total": total, "ok": ok, "broken": len(broken), "broken_details": broken})

def cmd_sync(config, args):
    output({"status": "info", "message": "Use: python3 scripts/sync_github_images.py"})

def main():
    parser = argparse.ArgumentParser(description="Image Agent")
    sub = parser.add_subparsers(dest="command")
    p_add = sub.add_parser("add"); p_add.add_argument("char_id"); p_add.add_argument("source")
    p_list = sub.add_parser("list"); p_list.add_argument("char_id")
    sub.add_parser("check")
    p_sync = sub.add_parser("sync"); p_sync.add_argument("char_id", nargs="?")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()
    
    config = load_config()
    
    if args.command == "add": cmd_add(config, args)
    elif args.command == "list": cmd_list(config, args)
    elif args.command == "check": cmd_check(config, args)
    elif args.command == "sync": cmd_sync(config, args)
    else: parser.print_help()

if __name__ == "__main__": main()
